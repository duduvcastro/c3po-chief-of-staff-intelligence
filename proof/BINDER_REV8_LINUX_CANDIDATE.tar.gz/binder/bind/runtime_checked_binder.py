"""Same-process guard for the exact reviewed binder and two reviewed offline rehearsal tools."""
import hashlib
import json
from pathlib import Path
import sys
import types

IDENTITY_SHA256 = '4328b6364029a417859fa58ec5ea2e52b715355edbc33d81adafacae1b3f0be3'
REVIEWED_TOOLS = {
    'rehearse': ('rehearse.py', '04a6767df360996de20d72b9d68d409712149f8d15fbefc521c2cf43833e8b44'),
    'runbook-tests': ('tests/runbook_blocks.py', 'e434a7c3da89eed9d787705d97921fdc47573a51b1fd5f903c5cbf7a99fd4cc7'),
}


def main():
    home = Path(__file__).resolve().parent
    root = home.parents[1]
    try:
        raw = (home / 'RUNTIME_IDENTITY.json').read_bytes()
        if hashlib.sha256(raw).hexdigest() != IDENTITY_SHA256:
            raise ValueError('RUNTIME_IDENTITY_EXTERNAL_PIN')
        expected = json.loads(raw)
        helper = (home / 'runtime_identity.py').read_bytes()
        if hashlib.sha256(helper).hexdigest() != expected.get('runtime_guard_sha256'):
            raise ValueError('RUNTIME_GUARD_BYTES')
        module = types.ModuleType('runtime_identity')
        module.__file__ = str(home / 'runtime_identity.py')
        sys.modules['runtime_identity'] = module
        exec(compile(helper, module.__file__, 'exec'), module.__dict__)
        observed = module.observe(root, (home / 'runtime_identity.py',), expected=expected)
        verdict = module.compare(expected, observed)
        source = module.read_regular(home / 'bind_once.py')
        if module.sha(source) != module.BINDER_SHA256 or module.sha(module.read_regular(home / 'ACCEPTED_SEALS.json')) != module.ACCEPTED_SHA256:
            raise ValueError('RUNTIME_BINDER_OR_ACCEPTANCE_BYTES')
        if sys.argv[1:] == ['--check-runtime']:
            print(json.dumps(verdict, sort_keys=True))
            return 0
        if sys.argv[1:2] == ['--run-reviewed-tool']:
            if len(sys.argv) < 3 or sys.argv[2] not in REVIEWED_TOOLS:
                raise ValueError('RUNTIME_TOOL_NOT_APPROVED')
            relative, pin = REVIEWED_TOOLS[sys.argv[2]]
            executed_path = home / relative
            consumed = module.read_regular(executed_path)
            if module.sha(consumed) != pin:
                raise ValueError('RUNTIME_TOOL_BYTES')
            argv = [str(executed_path)] + sys.argv[3:]
        else:
            executed_path, consumed = home / 'bind_once.py', source
            argv = [str(executed_path)] + sys.argv[1:]
    except Exception as error:
        code = str(error) if type(error).__name__ == 'Refused' else (
            str(error) if type(error) is ValueError and str(error).startswith('RUNTIME_') else 'RUNTIME_CHECK_FAILED')
        print(json.dumps({'status': 'REFUSED_RUNTIME', 'code': code}, sort_keys=True))
        return 2
    # Guard errors are separated from execution errors. The original binder/tool's
    # warnings, exception and exit semantics are preserved instead of relabelled.
    sys.argv = argv
    scope = {'__name__': '__main__', '__file__': str(executed_path), '__package__': None,
             '__builtins__': __builtins__}
    exec(compile(consumed, str(executed_path), 'exec'), scope)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
