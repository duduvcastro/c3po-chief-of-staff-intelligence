from functools import lru_cache
from pathlib import Path

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


def _default_paths() -> tuple[Path, Path, Path]:
    backend_root = Path(__file__).resolve().parent.parent
    if backend_root.name == "backend":
        project_root = backend_root.parent
        return project_root.parent, project_root / "db", project_root / "data" / "one-pagers"
    return Path("/legacy"), Path("/app/db"), Path("/app/generated-one-pagers")


DEFAULT_LEGACY_ROOT, DEFAULT_MIGRATIONS_DIR, DEFAULT_ONE_PAGER_OUTPUT_DIR = _default_paths()


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="C3PO_", extra="ignore", populate_by_name=True)

    # Explicit owner-confirmed quantity basis; never infer from acquisition cost.
    portfolio_split_adjusted_symbols: str | None = None

    app_name: str = "C3PO | Chief of Staff Intelligence"
    environment: str = "development"
    database_url: str = ""
    r2d2_risk_database_url: str = Field(default="", repr=False)
    legacy_root: Path = DEFAULT_LEGACY_ROOT
    migrations_dir: Path = DEFAULT_MIGRATIONS_DIR
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000,http://localhost:8081,http://127.0.0.1:8081"
    auth_required: bool = False
    auth_email: str = "eu@eduardocastro.com.br"
    auth_secret: str = "development-only-change-me"
    auth_code_minutes: int = 10
    auth_request_limit_per_email: int = 5
    auth_request_limit_per_ip: int = 10
    auth_verify_failure_limit_per_ip: int = 15
    auth_rate_limit_minutes: int = 15
    auth_session_hours: int = 24
    auth_owner_session_hours: int = 24
    auth_owner_idle_minutes: int = Field(default=360, ge=1, le=1440)
    auth_member_idle_minutes: int = Field(default=60, ge=1, le=1440)
    auth_cookie_secure: bool = True
    public_url: str = "https://c3po.eduardocastro.com.br"
    system_health_external_timeout_seconds: float = 6.0
    system_health_probe_timeout_seconds: float = Field(default=2.0, ge=0.25, le=5.0)
    github_api_url: str = "https://api.github.com"
    github_repository: str = "duduvcastro/c3po-chief-of-staff-intelligence"
    github_governance_token: str = Field(
        default="",
        validation_alias=AliasChoices(
            "C3PO_GITHUB_GOVERNANCE_TOKEN",
            "C3PO_GITHUB_TOKEN",
        ),
    )
    deploy_version_file: Path = DEFAULT_LEGACY_ROOT / ".deploy-version"
    build_sha: str = "development"
    sentry_dsn: str = ""
    sentry_sample_rate: float = Field(default=1.0, ge=0.0, le=1.0)
    sentry_traces_sample_rate: float = Field(default=0.0, ge=0.0, le=0.01)
    push_vapid_private_key: str = ""
    push_vapid_public_key: str = ""
    push_vapid_subject: str = "mailto:eu@eduardocastro.com.br"
    push_timeout_seconds: float = Field(default=3.0, ge=1.0, le=10.0)
    healthcheck_valuation_worker_url: str = ""
    healthcheck_cash_yield_url: str = ""
    healthcheck_code_census_url: str = ""
    healthcheck_postgres_backup_url: str = ""
    healthcheck_governance_url: str = ""
    healthcheck_postgres_restore_configured: bool = False
    healthcheck_trivy_configured: bool = False
    healthcheck_unattended_upgrades_configured: bool = False
    postgres_backup_bucket: str = ""
    postgres_backup_region: str = "us-east-1"
    postgres_backup_endpoint: str = ""
    postgres_backup_access_key_id: str = ""
    postgres_backup_secret_access_key: str = ""
    postgres_backup_prefix: str = "c3po-postgres"
    exchange_server: str = Field(default="", validation_alias=AliasChoices("C3PO_EXCHANGE_SERVER", "EXCHANGE_SERVER"))
    exchange_user: str = Field(default="", validation_alias=AliasChoices("C3PO_EXCHANGE_USER", "EXCHANGE_USER"))
    exchange_app_password: str = Field(default="", validation_alias=AliasChoices("C3PO_EXCHANGE_APP_PASSWORD", "EXCHANGE_APP_PASSWORD"))
    notification_exchange_server: str = Field(
        default="",
        validation_alias=AliasChoices("C3PO_NOTIFICATION_EXCHANGE_SERVER", "NOTIFICATION_EXCHANGE_SERVER"),
    )
    notification_exchange_user: str = Field(
        default="",
        validation_alias=AliasChoices("C3PO_NOTIFICATION_EXCHANGE_USER", "NOTIFICATION_EXCHANGE_USER"),
    )
    notification_exchange_app_password: str = Field(
        default="",
        validation_alias=AliasChoices(
            "C3PO_NOTIFICATION_EXCHANGE_APP_PASSWORD",
            "NOTIFICATION_EXCHANGE_APP_PASSWORD",
        ),
    )
    pluggy_base_url: str = Field(default="https://api.pluggy.ai", validation_alias=AliasChoices("C3PO_PLUGGY_BASE_URL", "PLUGGY_BASE_URL"))
    pluggy_client_id: str = Field(default="", validation_alias=AliasChoices("C3PO_PLUGGY_CLIENT_ID", "PLUGGY_CLIENT_ID"))
    pluggy_client_secret: str = Field(default="", validation_alias=AliasChoices("C3PO_PLUGGY_CLIENT_SECRET", "PLUGGY_CLIENT_SECRET"))
    pluggy_item_ids: str = Field(default="", validation_alias=AliasChoices("C3PO_PLUGGY_ITEM_IDS", "PLUGGY_ITEM_IDS"))
    pluggy_timeout_seconds: float = 18.0
    pluggy_refresh_minimum_minutes: int = 55
    brapi_token: str = Field(default="", validation_alias=AliasChoices("C3PO_BRAPI_TOKEN", "BRAPI_TOKEN"))
    brapi_base_url: str = "https://brapi.dev"
    brapi_plan: str = "unconfigured"
    eodhd_api_token: str = Field(default="", validation_alias=AliasChoices("C3PO_EODHD_API_TOKEN", "EODHD_API_TOKEN"))
    eodhd_base_url: str = "https://eodhd.com"
    eodhd_plan: str = "unconfigured"
    chewie_daily_symbol_budget: int = 2_500
    finnhub_api_token: str = Field(default="", validation_alias=AliasChoices("C3PO_FINNHUB_API_TOKEN", "FINNHUB_API_TOKEN"))
    finnhub_base_url: str = "https://finnhub.io"
    fmp_api_token: str = Field(default="", validation_alias=AliasChoices("C3PO_FMP_API_TOKEN", "FMP_API_TOKEN"))
    fmp_base_url: str = "https://financialmodelingprep.com"
    fmp_plan: str = "unconfigured"
    massive_api_token: str = Field(
        default="",
        validation_alias=AliasChoices("C3PO_MASSIVE_API_TOKEN", "MASSIVE_API_TOKEN"),
    )
    massive_base_url: str = "https://api.massive.com"
    massive_plan: str = "unconfigured"
    massive_flat_files_access_key: str = ""
    massive_flat_files_secret_key: str = ""
    massive_flat_files_endpoint: str = "https://files.massive.com"
    massive_flat_files_bucket: str = "flatfiles"
    day_d_dataset_root: Path = Path("/app/day-d-data")
    day_d_dataset_min_free_disk_gb: float = 20.0
    day_d_historical_download_authorized: bool = False
    day_d_point_in_time_reference_authorized: bool = False
    day_d_b2_key_id: str = ""
    day_d_b2_application_key: str = ""
    day_d_b2_bucket: str = ""
    day_d_b2_endpoint: str = "https://s3.us-east-005.backblazeb2.com"
    day_d_b2_region: str = "us-east-005"
    openai_admin_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("C3PO_OPENAI_ADMIN_API_KEY", "OPENAI_ADMIN_KEY"),
    )
    openai_usage_project_ids: str = ""
    anthropic_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("C3PO_ANTHROPIC_API_KEY", "ANTHROPIC_API_KEY"),
    )
    anthropic_admin_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("C3PO_ANTHROPIC_ADMIN_API_KEY", "ANTHROPIC_ADMIN_KEY"),
    )
    anthropic_usage_workspace_ids: str = ""
    market_data_timeout_seconds: float = 15.0
    market_data_max_retries: int = 2
    r2d2_cash_yield_http_timeout_seconds: float = 45.0
    one_pager_output_dir: Path = DEFAULT_ONE_PAGER_OUTPUT_DIR
    investor_relations_output_dir: Path = DEFAULT_ONE_PAGER_OUTPUT_DIR.parent / "investor-relations"
    cvm_data_base_url: str = "https://dados.cvm.gov.br/dados"
    sec_data_base_url: str = "https://data.sec.gov"
    sec_archives_base_url: str = "https://www.sec.gov"
    sec_fulltext_base_url: str = "https://efts.sec.gov"
    sec_user_agent: str = "C3PO Chief of Staff Intelligence eu@eduardocastro.com.br"
    investor_relations_poll_minutes: int = 15
    investor_relations_cvm_poll_minutes: int = 120
    investor_relations_ri_poll_minutes: int = 60
    investor_relations_sec_watchlist: str = "AMZN,MSFT,META,AVGO,TTWO,VOO,MHVYF"
    server_usage_server_id: str = "lightsail-sa-east-1"
    server_usage_server_name: str = "Chief of Staff Intelligence"
    server_usage_region: str = "São Paulo · sa-east-1"
    server_usage_cpu_count: int = 2
    server_usage_proc_stat_path: Path = Path("/proc/stat")
    server_usage_proc_loadavg_path: Path = Path("/proc/loadavg")
    server_usage_disk_path: Path = Path("/")
    server_usage_interval_seconds: int = 60
    server_usage_retention_days: int = Field(default=90, ge=7, le=3_650)
    performance_flush_seconds: int = Field(default=60, ge=30, le=300)
    performance_retention_days: int = Field(default=90, ge=30, le=3_650)
    performance_minimum_sample_sessions: int = Field(default=5, ge=3, le=30)
    server_usage_cpu_peak_warning_percent: float = 85.0
    server_usage_cpu_peak_critical_percent: float = 95.0
    server_usage_cpu_average_warning_percent: float = 70.0
    server_usage_cpu_average_critical_percent: float = 85.0
    server_usage_disk_warning_percent: float = 70.0
    server_usage_disk_critical_percent: float = 85.0
    r2d2_experiment_code: str = "R2D2-90D-001"
    r2d2_start_date: str = "2026-08-17"
    r2d2_checkpoint_days: int = Field(
        default=90,
        validation_alias=AliasChoices("C3PO_R2D2_CHECKPOINT_DAYS", "C3PO_R2D2_DURATION_DAYS"),
    )
    r2d2_starting_capital_usd: float = 1_000_000.0
    r2d2_cycle_seconds: int = 60
    r2d2_risk_monitor_enabled: bool = False
    r2d2_risk_monitor_interval_seconds: float = 3.0
    r2d2_fast_risk_watcher_enabled: bool = False
    r2d2_fast_risk_watcher_interval_seconds: float = 1.0
    r2d2_fast_risk_tick_max_age_seconds: float = 10.0
    r2d2_fast_risk_atr_max_age_seconds: float = 30.0
    r2d2_entry_score_adapter_enabled: bool = False
    # Independent V2 process; no collector or release is enabled by this change.
    r2d2_v2_live_policy_file: str = ""
    r2d2_v2_live_policy_sha: str = ""
    r2d2_v2_capacity_required: bool = False
    r2d2_v2_capacity_veto_mode: str = "DISPATCH_AND_DERIVATION_ONLY"
    r2d2_v2_capacity_config_file: str = ""
    r2d2_v2_capacity_config_sha: str = ""
    r2d2_v2_shadow_enabled: bool = False
    r2d2_v2_massive_bars_enabled: bool = False
    r2d2_v2_massive_journal_dir: Path = Path("/app/data/r2d2-v2-massive")
    r2d2_v2_shadow_source_dir: Path = Path("/app/data/r2d2-v2-source")
    r2d2_v2_shadow_release_file: Path = Path("/app/data/r2d2-v2-release.json")
    r2d2_v2_shadow_release_sha: str = ""
    r2d2_v2_shadow_poll_seconds: float = Field(default=1.0, ge=0.25, le=5.0)
    r2d2_shadow_candidate_log_enabled: bool = False
    r2d2_shadow_candidate_outcomes_enabled: bool = False
    r2d2_shadow_candidate_evidence_dir: Path = Path(
        "/app/day-d-data/evidence/r2d2-shadow-candidate-log-v1"
    )
    r2d2_cash_yield_accounting_enabled: bool = False
    # This is a hard per-name ceiling, not a target. Risk-normalized sizing
    # normally allocates 2%-3.08%; the live portfolio has used 6% since
    # 2026-08-20, so keep one canonical value instead of a compose override.
    r2d2_max_position_percent: float = 6.0
    r2d2_max_market_percent: float = 48.0
    r2d2_max_cash_percent: float = 25.0
    r2d2_min_cash_buffer_percent: float = 5.0
    r2d2_max_gross_exposure_percent: float = 95.0
    r2d2_daily_loss_limit_percent: float = 2.0
    r2d2_soft_loss_exit_percent: float = 0.25
    r2d2_max_position_loss_percent: float = 0.65
    r2d2_live_quote_max_age_seconds: int = 90
    r2d2_delayed_quote_protection_grace_minutes: float = 3.0
    r2d2_delayed_quote_fallback_max_age_minutes: float = 30.0
    r2d2_trade_cooldown_minutes: int = 8
    # A single bullish snapshot is too fragile to authorize capital. Require
    # the same symbol to pass on distinct live ticks in consecutive scans, and
    # keep one market-wide snapshot from filling every vacant portfolio slot.
    r2d2_entry_confirmation_reviews: int = Field(default=2, ge=1, le=5)
    r2d2_max_new_positions_per_scan: int = Field(default=4, ge=1, le=20)
    # Root-caused 2026-08-20: this default (not an env override) is what the
    # worker falls back to whenever a deploy doesn't carry forward a manual
    # production tweak -- it silently reverted from a 200 override earlier
    # today, hit the cap at 131 orders by mid-afternoon, and starved the rest
    # of the session of any new BUYs. Raised the versioned default itself so
    # this can't regress again. Risk per trade is now normalized (V20:
    # RISK_BUDGET_PERCENT of NAV per position), so the order count itself
    # carries far less risk than it did under the old fixed 2-6%-of-NAV
    # sizing -- 500 is generous headroom above a realistic day's volume
    # (~180 extrapolated from today) while still tripping on genuine
    # runaway/erratic behavior.
    r2d2_max_daily_orders: int = 500
    # EODHD account contract: 50 base symbols plus the active 500-symbol add-on,
    # shared across all markets in the R2D2 stream.
    r2d2_ws_max_symbols: int = 550
    r2d2_read_cache_open_seconds: int = Field(default=5, ge=0, le=60)
    r2d2_read_cache_closed_seconds: int = Field(default=30, ge=0, le=600)
    leah_sync_dedupe_window_seconds: int = Field(default=30, ge=0, le=600)
    leah_sync_deadline_seconds: int = Field(default=10, ge=1, le=120)
    leah_sync_cooldown_seconds: int = Field(default=30, ge=1, le=600)
    r2d2_ws_rotation_grace_cycles: int = 3
    r2d2_ws_rotation_core_percent: float = 50.0
    r2d2_microstructure_raw_capture_enabled: bool = False
    r2d2_microstructure_raw_dir: Path = Path(
        "/app/day-d-data/provider=eodhd/microstructure/raw"
    )
    r2d2_microstructure_raw_queue_size: int = 100_000
    r2d2_microstructure_raw_rotate_mb: int = 256
    r2d2_microstructure_raw_flush_every: int = 1_000
    r2d2_microstructure_processor_enabled: bool = True
    r2d2_microstructure_bbo_max_age_seconds: float = 2.0
    r2d2_microstructure_allowed_lateness_seconds: float = 2.0
    r2d2_microstructure_aggregate_queue_size: int = 100_000
    r2d2_microstructure_telemetry_enabled: bool = True
    r2d2_microstructure_telemetry_interval_seconds: float = 1.0
    # Valuation V3.2 price series (rev 7 §2.2): OFF by default; the nightly phase runs only when enabled by the mesa
    valuation_price_history_enabled: bool = False
    valuation_price_history_backfill_months: int = Field(default=36, ge=1, le=120)
    r2d2_fmp_prefilter_enabled: bool = True
    r2d2_fmp_prefilter_cache_seconds: int = 15
    r2d2_fmp_prefilter_max_quote_age_seconds: int = 120
    r2d2_fmp_prefilter_batch_size: int = 100
    r2d2_deployment_technical_review_per_market: int = 32
    r2d2_standard_technical_review_per_market: int = 24

    @property
    def allowed_origins(self) -> list[str]:
        return [value.strip() for value in self.cors_origins.split(",") if value.strip()]

    @property
    def sec_watchlist(self) -> list[str]:
        return [value.strip().upper() for value in self.investor_relations_sec_watchlist.split(",") if value.strip()]

    @property
    def pluggy_items(self) -> list[str]:
        normalized = self.pluggy_item_ids.replace(";", ",").replace("\n", ",")
        return [value.strip() for value in normalized.split(",") if value.strip()]

    @property
    def openai_usage_projects(self) -> list[str]:
        return [value.strip() for value in self.openai_usage_project_ids.split(",") if value.strip()]

    @property
    def anthropic_usage_workspaces(self) -> list[str]:
        return [value.strip() for value in self.anthropic_usage_workspace_ids.split(",") if value.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
