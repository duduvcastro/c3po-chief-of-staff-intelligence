"""Local controls of the actual rev3 shell guard; no binder operation is invoked.

The manual sealed-copy command is replaced with a sentinel AFTER its actual guard.
This measures guarded protocol reachability, never copy/prepare/host acceptance.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tempfile

import pytest

ROOT = Path(os.environ['RUNTIME_REV5_ROOT']).resolve()
OLD = Path(os.environ['RUNTIME_REV3_ROOT']).resolve()
ARTIFACTS = Path(os.environ['RUNTIME_REV5_QA_OUT']).resolve()
HOME = ROOT / 'binder/bind'
SHA = lambda value: hashlib.sha256(value).hexdigest()
COMMAND = '    "${PY}" "${PYFLAGS[@]}" "${BIND}" sealed-copy --out "${HOSTOPS02_COPY}" --source "${HOSTOPS02_SOURCE}"'
SLOT = 'hostops02-sealed-registry25-78eb4ab2'


def inventory(root):
    answer = {}
    for entry in sorted(root.rglob('*')):
        meta = entry.lstat()
        name = entry.relative_to(root).as_posix()
        row = {'mode': stat.S_IMODE(meta.st_mode), 'type': stat.S_IFMT(meta.st_mode)}
        if stat.S_ISLNK(meta.st_mode):
            row['target'] = os.readlink(entry)
        elif stat.S_ISREG(meta.st_mode):
            row['sha256'] = SHA(entry.read_bytes())
        else:
            assert stat.S_ISDIR(meta.st_mode)
        answer[name] = row
    return answer


@pytest.fixture(scope='session', autouse=True)
def no_runtime_or_base_mutation():
    before = {label: inventory(root) for label, root in [('rev3', ROOT), ('rev2', OLD)]}
    yield
    after = {label: inventory(root) for label, root in [('rev3', ROOT), ('rev2', OLD)]}
    assert after == before
    receipt = {'schema': 'MAC_RUNTIME_REV3_QA_INPUT_STABILITY_V1',
               'scope': 'LOCAL_SHELL_PROTOCOL_SENTINEL_NOT_SEALED_COPY_OR_HOST',
               'outer_python': sys.version, 'outer_executable': sys.executable,
               'runtime_python_executed_by_source': '3.12.14',
               'rev3_entries_before_after': len(before['rev3']),
               'rev2_entries_before_after': len(before['rev2']),
               'files_bytes_modes_links_changed': 0, 'actual_sealed_copy_calls': 0,
               'prepare_sign_dispatch_host_calls': 0,
               'inventory_before_sha256': SHA(json.dumps(before, sort_keys=True).encode()),
               'inventory_after_sha256': SHA(json.dumps(after, sort_keys=True).encode())}
    (ARTIFACTS / 'INPUT_STABILITY.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')


def execute(tmp_path, label, code, workspace):
    cache = tmp_path / 'cache'
    cache.mkdir(mode=0o700)
    env = os.environ.copy()
    env.update({'BIND_CANDIDATE_ROOT': str(ROOT / 'binder'),
                'BIND_WORK_ROOT': str(workspace), 'CONTROL_SENTINEL': str(tmp_path / 'sentinel'),
                'TMPDIR': str(cache), 'MODE': 'rehearsal'})
    env.pop('RUN_BASE', None)
    result = subprocess.run(['/bin/zsh', '-f', '-c', code], env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    (ARTIFACTS / (label + '.stdout.txt')).write_bytes(result.stdout)
    (ARTIFACTS / (label + '.stderr.txt')).write_bytes(result.stderr)
    (ARTIFACTS / (label + '.control.json')).write_text(json.dumps({
        'exit': result.returncode, 'stdout_sha256': SHA(result.stdout),
        'stderr_sha256': SHA(result.stderr), 'sentinel_reached': (tmp_path / 'sentinel').exists(),
        'actual_binder_operation_calls': 0,
        'scope': 'REAL_SOURCE_AND_GUARD_COMMAND_REPLACED_ONLY_AFTER_GUARD'}, sort_keys=True) + '\n')
    assert result.stderr == b'', result.stderr
    return result


def workspace(tmp_path):
    root = tmp_path / 'workspace'
    root.mkdir(mode=0o700)
    old_copy = root / 'hostops02-sealed'
    old_copy.mkdir(mode=0o700)
    (old_copy / 'prior-copy-sentinel').write_bytes(b'PRIOR_COPY_MUST_REMAIN_UNCHANGED\n')
    return root


@pytest.mark.parametrize('kind', ['fresh', 'directory', 'file', 'link', 'dangling'])
def test_manual_recipe_refuses_existing_destination_before_invocation(tmp_path, kind):
    work = workspace(tmp_path)
    destination = work / SLOT
    if kind == 'directory':
        destination.mkdir(mode=0o700)
    elif kind == 'file':
        destination.write_bytes(b'EXISTING_DESTINATION\n')
    elif kind in ('link', 'dangling'):
        target = tmp_path / 'external-target'
        if kind == 'link':
            target.mkdir(mode=0o700)
        destination.symlink_to(target)
    before = inventory(work)
    document = (HOME / 'RUNBOOK.md').read_text()
    section = document.split('### 10.1 ', 1)[1].split('### 10.4 ', 1)[0]
    block = re.search(r'```manual\n(.*?)\n```', section, re.S).group(1)
    assert block.count(COMMAND) == 1
    # The only replaced command would have been the binder sealed-copy itself.
    controlled = block.replace(COMMAND, "    print -r -- 'LOCAL_CONTROL_WOULD_INVOKE_SEALED_COPY' > \"${CONTROL_SENTINEL:?}\"")
    assert controlled.endswith('  fi\nfi')
    controlled = controlled[:-len('  fi\nfi')] + '  else\n    exit 23\n  fi\nelse\n  exit 24\nfi'
    controlled += '\nprint -r -- "COPY=${HOSTOPS02_COPY}" "WORK=${W}" "REFERENCE=${REFERENCE}"\n'
    result = execute(tmp_path, 'manual-' + kind, controlled, work)
    assert inventory(work) == before, 'No destination or prior copy may be changed by the guard'
    if kind == 'fresh':
        assert result.returncode == 0
        assert (tmp_path / 'sentinel').read_bytes() == b'LOCAL_CONTROL_WOULD_INVOKE_SEALED_COPY\n'
        assert ('COPY=' + str(work / SLOT)).encode() in result.stdout
        assert ('WORK=' + str(work)).encode() in result.stdout
        assert ('REFERENCE=' + str(work / 'hostfacts01-fable-20261002/bound/DISPATCH.BOUND.json')).encode() in result.stdout
        assert not destination.exists() and not destination.is_symlink()
    else:
        assert result.returncode == 23, result.stdout
        assert b'destino da c\xc3\xb3pia do registro25 j\xc3\xa1 existe' in result.stdout
        assert not (tmp_path / 'sentinel').exists()


def test_later_source_accepts_existing_copy_without_fresh_guard(tmp_path):
    work = workspace(tmp_path)
    (work / SLOT).mkdir(mode=0o700)
    before = inventory(work)
    code = 'L=later-step; source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh" || exit 24; print -r -- "${HOSTOPS02_COPY}"'
    result = execute(tmp_path, 'later-source-existing-copy', code, work)
    assert result.returncode == 0
    assert result.stdout.strip() == str(work / SLOT).encode()
    assert inventory(work) == before
    assert not (tmp_path / 'sentinel').exists()


def test_run_env_cannot_redirect_fixed_copy(tmp_path):
    work = workspace(tmp_path)
    run = work / 'binder-runs/sealed-copy-bootstrap'
    run.mkdir(mode=0o700, parents=True)
    decoy = tmp_path / 'decoy-copy'
    (run / 'run.env').write_text('HOSTOPS02_COPY=' + str(decoy) + '\n')
    before = inventory(work)
    code = 'L=sealed-copy-bootstrap; source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh" || exit 24; require_new_hostops02_copy || exit 23; print reached > "${CONTROL_SENTINEL:?}"'
    result = execute(tmp_path, 'run-env-copy-redirect', code, work)
    assert result.returncode == 24
    assert b'run.env tentou alterar destinos de escrita protegidos' in result.stdout
    assert not decoy.exists() and not (tmp_path / 'sentinel').exists()
    assert inventory(work) == before


def test_previous_physical_interpreter_slot_is_refused(tmp_path):
    cache = tmp_path / 'new-cache'
    cache.mkdir(mode=0o700)
    result = subprocess.run([str(OLD / 'venv/bin/python'), '-I', '-S', '-B', '-X',
                             'pycache_prefix=' + str(cache), str(HOME / 'runtime_checked_binder.py'),
                             '--check-runtime'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    (ARTIFACTS / 'old-runtime-slot.stdout.txt').write_bytes(result.stdout)
    (ARTIFACTS / 'old-runtime-slot.stderr.txt').write_bytes(result.stderr)
    assert result.returncode == 2
    assert result.stderr == b''
    report = json.loads(result.stdout)
    assert report['status'] == 'REFUSED_RUNTIME'
    assert report['code'] == 'RUNTIME_EXECUTABLE_SLOT'
    assert report == {'status': 'REFUSED_RUNTIME', 'code': 'RUNTIME_EXECUTABLE_SLOT'}


def test_manual_spare_reference_and_own_identity_are_explicit():
    document = (HOME / 'RUNBOOK.md').read_text()
    assert (ROOT / 'RUNBOOK.md').read_bytes() == (HOME / 'RUNBOOK.md').read_bytes()
    assert '### 10.5 SPARE: HOLD até a autoridade e o estado exatos' in document
    section = document.split('### 10.5 ', 1)[1].split('## 11.', 1)[0]
    for required in ('SPARE_PRIMARY_NEVER_PREPARED', 'PREPARED_NEVER_SENT_PAST_ITS_LATEST_START',
                     'Estado enviado, recusa no host, incerteza', 'BOOTSTRAP_IDENTITY, K3-K9 e A7 não permitem SPARE',
                     'Assino próprio', 'Não há receita de execução de SPARE'):
        assert required in section
    assert '```' not in section
    assert SHA((HOME / 'RUNTIME_IDENTITY.json').read_bytes()) != SHA((OLD / 'binder/bind/RUNTIME_IDENTITY.json').read_bytes())
    assert SHA((HOME / 'bind_once.py').read_bytes()) == '9fec60db32ac9a275876d6a421b95521aaf19f79ba05c0a088af07f6c26758ee'
    assert (HOME / 'bind_once.py').read_bytes() != (OLD / 'binder/bind/bind_once.py').read_bytes()
    assert SHA((HOME / 'ACCEPTED_SEALS.json').read_bytes()) == '78eb4ab25db448d677b5c54bb2f91346c194427fee88028260d1ba2f7be50d72'
    assert (HOME / 'ACCEPTED_SEALS.json').read_bytes() != (OLD / 'binder/bind/ACCEPTED_SEALS.json').read_bytes()


def test_current_morning_source_registry_family_and_window_pins():
    document=(HOME/'RUNBOOK.md').read_text()
    assert '12:26–12:31 UTC (09:26–09:31 BRT)' in document
    assert 'watchdog máximo80s' in document
    assert '08:26–12:30BRT' in document and '17:38–20:30' in document
    assert 'K5 não recebeu faixa matinal' in document
    assert '11omissões binder e9W1' in document
    assert 'capacidade depois de G19 ficam HOLD' in document
    registry=json.loads((HOME/'ACCEPTED_SEALS.json').read_bytes())
    assert len(registry['seals'])==25
    by={x['family']:x for x in registry['seals']}
    assert by['HOSTOPS02_BOOTSTRAP_IDENTITY']['sha256sums_sha256']=='7068c24fb3a771a5250e1070e46b6f98abb244d963809a668c331337493cf149'
    family=ROOT/'families/bootstrap_identity'
    assert SHA((family/'SHA256SUMS').read_bytes())==by['HOSTOPS02_BOOTSTRAP_IDENTITY']['sha256sums_sha256']
    probe=ROOT/'families/capacity_probe'
    assert SHA((probe/'SHA256SUMS').read_bytes())=='987ab4708e9a9d94c0c1a96f5fbbe160409c933376f3c099e7d0ce66ff25de58'
    assert not (probe/'work').exists(), 'External documentary evidence cannot be unlisted family bytes'
    assert '20:43–20:48UTC' not in document
    assert 'INDEX_BOOTSTRAP_REV5.json' in document
