"""Dated amendment delta; exact binder functions, no application/core/host imports."""
import ast
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
import pytest

SOURCE = Path(__file__).resolve().parents[1] / 'bind_once.py'
NAMES = {'A2_AMENDMENT4_REV3_SHA256', 'A2_AMENDMENT4_SESSIONS'}
FUNCTIONS = {'k9_dated_reserve', 'k8_e6_band', 'cited', 'complete_role', 'at', 'need', 'pointer_value'}
tree = ast.parse(SOURCE.read_bytes())
class Refused(Exception):
    pass
scope = {'datetime':datetime, 'timedelta':timedelta, 'timezone':timezone, 'Refused':Refused,
         'K9R_OPERATION':'GO_READONLY_HOSTOPS02_K9_PHASE_READ_01', 'MISSING':object(), 're':re}
selected = [n for n in tree.body if (isinstance(n, ast.FunctionDef) and n.name in FUNCTIONS)
            or (isinstance(n, ast.Assign) and any(isinstance(t,ast.Name) and t.id in NAMES for t in n.targets))]
exec(compile(ast.Module(body=selected,type_ignores=[]), str(SOURCE), 'exec'), scope)

def ctx(day='2026-10-08', start='2026-10-08T00:30:00+00:00', end='2026-10-08T00:59:59+00:00'):
    receipt = {'mode':'RESULT', 'k9_operation':'commit_result', 'day':day, 'slot':'SPARE',
       'phase_result':'COMPLETE', 'outcome':'K9_PHASE_RESULT_COMPLETE_ALL_OBSERVED',
       'clock':{'utc_start':'2026-10-08T00:26:00+00:00','utc_end':'2026-10-08T00:27:00+00:00'},
       'items':{'launch_record':{'slot':'SPARE'}}}
    return {'plan':{'day':day}, 'window':{'start':datetime.fromisoformat(start),'end':datetime.fromisoformat(end)},
      'entries':[{'role':'COMMIT','operation':scope['K9R_OPERATION']}], 'receipts':{'COMMIT':receipt},
      'evidence_facts':[{'role':'COMMIT','complete':True}]}

@pytest.mark.parametrize('case', ['P','observed_P','partial','unknown','missing','other_result','early','late','wrong_day'])
def test_extended_band_refuses_without_real_dated_reserve(case):
    c=ctx();r=c['receipts']['COMMIT']
    if case=='P':r['slot']='PRIMARY'
    elif case=='observed_P':r['items']['launch_record']['slot']='PRIMARY'
    elif case=='partial':r['phase_result']='PARTIAL'
    elif case=='unknown':c['evidence_facts'][0]['complete']=False
    elif case=='missing':c['entries']=[]
    elif case=='other_result':r['k9_operation']='publish_result'
    elif case=='early':r['clock']['utc_start']='2026-10-08T00:25:59+00:00'
    elif case=='late':r['clock']['utc_end']='2026-10-08T00:46:00+00:00'
    else:r['day']='2026-10-09'
    with pytest.raises(Refused,match='^K8_E6_WINDOW_OUTSIDE_A2_BAND$'):scope['k8_e6_band'](c)

@pytest.mark.parametrize('end', ['2026-10-08T00:59:58+00:00','2026-10-08T00:59:59+00:00'])
def test_real_reserve_extended_boundary(end):
    result=scope['k8_e6_band'](ctx(end=end))
    assert result['spare_after_2100_authorized'] is True
    assert result['dated_amendment_sha256']==scope['A2_AMENDMENT4_REV3_SHA256']

def test_one_second_beyond_extension_is_refused():
    with pytest.raises(Refused,match='^K8_E6_WINDOW_OUTSIDE_A2_BAND$'):
        scope['k8_e6_band'](ctx(end='2026-10-08T01:00:00+00:00'))

@pytest.mark.parametrize('day', ['2026-10-06','2026-10-07','2026-10-10'])
def test_adjacent_dates_do_not_inherit_extension(day):
    eve=datetime.strptime(day,'%Y-%m-%d').replace(tzinfo=timezone.utc)-timedelta(days=1)
    c=ctx(day,(eve+timedelta(days=1,minutes=30)).isoformat(),(eve+timedelta(days=1,minutes=59,seconds=59)).isoformat())
    with pytest.raises(Refused,match='^K8_E6_WINDOW_OUTSIDE_A2_BAND$'):scope['k8_e6_band'](c)

@pytest.mark.parametrize('day', ['2026-10-06','2026-10-07','2026-10-08','2026-10-09','2026-10-10'])
def test_normal_band_unchanged(day):
    eve=datetime.strptime(day,'%Y-%m-%d').replace(tzinfo=timezone.utc)-timedelta(days=1)
    c=ctx(day,(eve+timedelta(hours=20,minutes=38)).isoformat(),(eve+timedelta(hours=23,minutes=55)).isoformat())
    assert scope['k8_e6_band'](c)['spare_after_2100_authorized'] is False

@pytest.mark.parametrize('day', ['2026-10-06','2026-10-07','2026-10-08','2026-10-09','2026-10-10'])
@pytest.mark.parametrize('grid,track', [('G19','P'),('G19','S'),('G18','S')])
def test_g19_reserve_date(grid,track,day):
    if grid=='G19' and track=='S' and day not in ('2026-10-08','2026-10-09'):
        with pytest.raises(Refused,match='^K9_G19_S_OUTSIDE_DATED_AMENDMENT$'):
            scope['k9_dated_reserve'](grid,day,{'track':track})
    else:scope['k9_dated_reserve'](grid,day,{'track':track})


def test_actual_zulu_clock_is_accepted_on_both_python_layers():
    c=ctx();c['receipts']['COMMIT']['clock']={'utc_start':'2026-10-08T00:26:00Z','utc_end':'2026-10-08T00:27:00Z'}
    assert scope['k8_e6_band'](c)['spare_after_2100_authorized'] is True

@pytest.mark.parametrize('clock', [{}, {'utc_start':'2026-10-08T00:26:00','utc_end':'2026-10-08T00:27:00'}, {'utc_start':7,'utc_end':None}])
def test_missing_naive_or_nonstring_clocks_are_refused(clock):
    c=ctx();c['receipts']['COMMIT']['clock']=clock
    with pytest.raises(Refused,match='^K8_E6_WINDOW_OUTSIDE_A2_BAND$'):scope['k8_e6_band'](c)


def test_second_dated_night_extended_boundary():
    c=ctx('2026-10-09','2026-10-09T00:30:00+00:00','2026-10-09T00:59:59+00:00')
    c['receipts']['COMMIT']['clock']={'utc_start':'2026-10-09T00:26:00Z','utc_end':'2026-10-09T00:27:00Z'}
    assert scope['k8_e6_band'](c)['spare_after_2100_authorized'] is True
