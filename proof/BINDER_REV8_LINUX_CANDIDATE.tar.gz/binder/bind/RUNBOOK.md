# RUNBOOK candidato matinal — revisão 7

Esta nova cópia candidata integra a fontec573, BOOT matinal7068 e PROBE987ab no registro25 78eb. É para revisão por hash; não é promoção, assinatura, GO ou autorização de execução no host. As instalações/ativações de segunda e seus GOs foram consumidos. Nenhum conjunto preparado anterior é reutilizado. Os selos e provas da rev3 ficam preservados como históricos, sem transferência de identidade física ou PASS.

As receitas gerais abaixo usam o wrapper medido desta própria cópia. O operador escolhe os parâmetros exatos da operação atual pelos contratos selados e recibos que a regra exige. Não copiar parâmetros, datas ou autorizações dos runbooks históricos preservados. O Codex não executa os passos host, push ou dispatch.

## Entrada única conferida

A entrada candidata é binder/bind/runtime_checked_binder.py, executada somente pelo interpretador absoluto derivado desta cópia pelo runbook_env.zsh e conferido contra RUNTIME_IDENTITY.json, com -I -S -B e pycache_prefix isolado. Antes de qualquer prepare, a guarda confere identidade física do Python, stdlib, dependências, helper, arquivos consumidos e fonte/registo por hash. Nenhum fallback para outro Python ou calendário é permitido. O recibo de check-runtime é leitura local e não prova Linux ou host.

A fonte 9fec60db32ac9a275876d6a421b95521aaf19f79ba05c0a088af07f6c26758ee e o registro 78eb4ab25db448d677b5c54bb2f91346c194427fee88028260d1ba2f7be50d72 selecionam 25 entradas, 23 famílias e cinco núcleos explícitos. Somente as duas linhas BOOT/PROBE mudam em relação ao registro operativo rev3; os outros 23 registros são iguais. BOOT usa core_bootstrap_identity e K3-K9/A7 conservam seus núcleos próprios. Ver INDEX_BOOTSTRAP_REV7.json para os pins atuais desta cópia. INDEX_BOOTSTRAP_REV3.json, INDEX_BOOTSTRAP_REV2.json, BOOTSTRAP_INTEGRATION_STATUS.json e historical-runtime-rev3 são históricos, não instruções nem aceitação desta cópia.

Antes das receitas, BIND_CANDIDATE_ROOT nomeia o diretório binder desta própria cópia candidata; BIND_WORK_ROOT nomeia uma raiz privada externa. A identidade contém hashes/origens; runbook_env.zsh deriva o executável absoluto de venv/bin/python desta cópia e o wrapper confere a identidade física. Não apontar para a cópia ADC, nem mover o runtime Mac sem nova medição/revisão. O Codex não executou qualquer passo operativo.

## 0. Regras que valem para todos os blocos

- Um bloco por vez. Ler o `exit=` impresso e o JSON antes de seguir. `set -e` não vale neste shell: os blocos
  decidem por `if` e por `&&` e conferem o código de saída.
- Todo bloco começa com `L=<label>; if source .../runbook_env.zsh; then`, porque o estado do shell não persiste. O
  `source` liga `noclobber`: nenhuma saída salva é sobrescrita. Trocar `<label>` pelo rótulo da execução (o mesmo
  do arquivo de parâmetros), por exemplo `w1-20261002-a`. No zsh, sempre `"${VAR}"` com chaves.
- Um bloco que só pode rodar uma vez, quando repetido, imprime `JÁ FEITO: ...` e mostra os valores já gravados;
  não roda o passo de novo e não imprime `exit=`.
- Nenhum hash é copiado à mão: todo hash vem de uma saída salva, por `pick.py` ou por um comando do bloco.
- O binder nunca imprime o alvo SSH, o caminho da chave nem o do known-hosts, e nunca abre esses dois arquivos (só
  `lstat`). Não imprimir à mão (`cat`) `DISPATCH.BOUND.json`, o GO nem o payload final no canal: os três contêm o alvo.
- Recusa do binder: um objeto JSON (impresso em várias linhas) com `"status": "REFUSED"` e `"code"`, exit 2, nunca
  traceback. O campo `created_by_this_run` diz se a execução recusada já tinha criado algo; se tinha, parar, não
  mexer, não repetir no mesmo diretório, relatar.
- Nada sob o diretório vinculado é editado, movido, tem modo trocado ou é apagado para "fazer passar". Um byte
  mudado é outro hash e outra assinatura. Nenhum diretório é criado dentro dele (o binder recusa um conjunto com
  qualquer diretório além de `templates` e `.dispatch-root`: `BOUND_SET_HOLDS_A_DIRECTORY_THAT_IS_NOT_ITS_OWN`).
- Horas para o dono em BRT; no canal, UTC. Antes de todo pedido ao dono: banner no Mac e push no telefone.
- Não editar `bind_once.py` nem `ACCEPTED_SEALS.json` entre o prepare e o sign de uma execução: o hash dos dois está
  na folha que o dono assina, e o sign recusa (`BINDER_CHANGED_SINCE_PREPARE`). Um conjunto já assinado só é
  conferido (`check`, `status`, citação como evidência) por bytes do binder que ainda construam os mesmos documentos
  e a mesma pergunta: não mudar o texto das perguntas nem a construção entre o precheck real e o readback.

### Onde fica o diretório vinculado (decidir antes do bloco 1)

A raiz de uso único (`.dispatch-root`) entra no GO assinado com caminho, device e inode, e os cinco blobs entram na
configuração com o caminho do diretório em que foram vinculados.

- **Nunca rodar o dispatcher a partir de uma cópia.** O `check` e o `publish-proof` de uma cópia recusam
  (`BOUND_SET_RELOCATED_OR_CLAIM_ROOT_CHANGED`), mas o `dispatch_once.py` da cópia, enquanto o diretório original
  existir, lê os blobs e usa a raiz de uso único **nos caminhos originais**: prepara e reivindica lá, e o recibo cai
  lá. O uso único é mantido, mas o que foi consumido está no original, não na cópia.
- O `status` de uma cópia: se a própria cópia guarda uma tentativa terminada (cópia de arquivo, feita depois do
  resume), confere os bytes da cópia; senão lê a raiz **original** nomeada na folha, quando ela ainda existe com a
  identidade assinada (`claim_root_read: ORIGINAL_NAMED_ON_THE_SHEET`); se o original sumiu, responde
  `RELOCATED_COPY_STATE_NOT_KNOWN` e não afirma que nada foi consumido.
- **(A) assinatura e despacho na mesma sentada:** `OUT` no scratchpad (`${RUN}/bound`) e cópia para o diretório
  durável no bloco 11. É o padrão do bloco 1a.
- **(B) assinatura de véspera, ou qualquer intervalo de horas entre o sign e o resume:** criar `OUT` já no diretório
  durável (`OUT=${W}/once-<label>/bound` no `run.env`). `/private/tmp` é limpo de arquivos parados há 3 dias e some
  num reinício do Mac. O bloco 11 então só copia as saídas dos passos e confere.

As saídas de operação ficam em `W/binder-runs/<label>` por padrão; os ensaios em `W/binder-rehearsals`. `W` e qualquer RUN_BASE têm de resolver fora de OPERATIVE_ROOT, inclusive por aliases ou symlinks. Diretórios de runs são criados 0700 após a identidade ser conferida. Uma cópia selada nunca recebe prepare.json, run.env, journal ou saídas do ensaio.

## 2. Parâmetros da primeira noite

A fontec573 exige a família HOSTOPS02_BOOTSTRAP_IDENTITY matinal7068 com núcleo core_bootstrap_identity explícito. O programa é GO_WRITE_HOSTOPS02_BOOTSTRAP_IDENTITY_01, revisão1; conserva o slot FIRST_NIGHT_20261006 e sua chave de tentativa única. A janela compilada é 06/10/2026 12:26–12:31 UTC (09:26–09:31 BRT), watchdog máximo80s. O rótulo histórico do slot não desloca a execução para a noite. Janela ou parâmetro divergente recusa antes do efeito.

O arquivo PARAM precisa carregar os dez campos do plan descritos no CONTRACT.txt/INTERFACE.json da família: mode, epoch, slot, attempt_key, constants, parent_rows, data_volume_chain, source_rows, evidence_boot_id_sha256 e policy_read. O binder transforma $bootstrap_source_rows somente de componentes COMPLETE da TREE_PRE vinculada e aceita o tipo dir real da K9R248c. Não fabricar device/inode/boot, nem antecipar recibo BOOT no primeiro prepare.

Evidências anteriores: E0, TREE_PRE e M2 POST com conjunto BOUND/saída/exit/stderr e identidade conferidos. A TREE_PRE só pode ser parcial pelas exceções exatas de ausência esperadas; os demais itens têm de ser COMPLETE. O boot deve continuar igual ao M2 POST. Reboot rompe essa proveniência: HOLD sem repetir M2 por inferência.

O primeiro K3-K9 matinal exige BOOT COMPLETE já terminado, mesma identidade e cópias exatas das linhas observadas. A7 fica depois do K3-K9 e antes de qualquer recreate, no mesmo BOOT do worker observado; exige K3-K9 COMPLETE ligado por request/sheet/evidence ao BOOT, nunca efeitos presumidos como observações. A TREE/POLICY diária conserva sua exigência de completude. Reboot, identidade incerta ou recibo parcial mantém HOLD sem nova tentativa.

Cada pedido é revisto por hash, recebe Assino próprio e gates exatos antes dos passos dependentes. O único efeito BOOT é o claim permanente; criação possível consome a tentativa, inclusive quando o restante termina PARCIAL. Não há exclusão, reparo, retry, SPARE ou autorização herdada.

## 3. Sequência de uma execução real

<!-- bloco: verificar -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  cd "${B}" && shasum -a 256 -c SHA256SUMS && shasum -a 256 SHA256SUMS \
   && cd "${W1_FAMILY}" && shasum -a 256 -c SHA256SUMS && shasum -a 256 SHA256SUMS \
   && cd "${HOSTOPS_FAMILY}" && shasum -a 256 -c SHA256SUMS | grep -vc ': OK$' ; shasum -a 256 "${HOSTOPS_FAMILY}/SHA256SUMS" ; date -u +%Y-%m-%dT%H:%M:%SZ
fi
```

Conferir a olho: tudo `OK` no manifesto do binder; W1 `108b74ca…3347` com 15 OK; HOSTOPS01 `5609b334…71c1` e a
contagem de linhas não-OK igual a `0`; a hora UTC.

### Identidade — antes do prepare do binder e de qualquer bloco dependente

<!-- bloco: identidade-runtime -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  "${PY}" "${PYFLAGS[@]}" "${BIND}" --check-runtime; echo "exit=$?"
fi
```

Só `VERIFIED_RUNTIME` com exit 0 permite continuar. Uma recusa conserva HOLD;
não trocar PY, pinos ou arquivos para contorná-la. O mesmo guard ocorre no source de **cada** bloco.

### Bloco 1a — diretório da execução e parâmetros (uma vez)

<!-- bloco: preparar-run manual -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/run.env" ]]; then echo "JÁ FEITO: ${RUN}/run.env existe e não é reescrito. Valores gravados:"; cat "${RUN}/run.env"
  else
    create_external_private_directory "${RUN}" \
     && print -r -- "FAMILY=${W1_FAMILY}
OP=GO_READONLY_W1PREFLIGHT_01
MODE=real
PARAMS=${RUN}/PARAMETERS.json
OUT=${RUN}/bound" > "${RUN}/run.env" && cat "${RUN}/run.env"
  fi
fi
```

Para HOSTOPS01: `FAMILY=${HOSTOPS_FAMILY}` e o `OP` da operação. Para HOSTOPS02: `FAMILY=${HOSTOPS02_COPY}/<diretório da
operação>` (a cópia selada da seção 10.1, nunca o diretório de trabalho), o `OP` da operação e, sempre que a folha nomear
portões de envio (todas as gravações do HOSTOPS02 e o M2), `GATES=${RUN}/GATES.json` (seção 10.4 desta candidata): sem ele os blocos 6 e 9
param (`PARADO`), e o bloco 1b avisa. `RESUME_GATE` não é mais usado: o bloco 9 roda `check --step resume` em todo
conjunto do HOSTOPS02. Para a opção (B): `OUT=${W}/once-<label>/bound`
(e `mkdir -p "${W}/once-<label>"`, modo 700, antes do prepare). Depois escrever `${RUN}/PARAMETERS.json` (contrato selado da família e parâmetros atuais)
com a ferramenta de escrita, e conferir com `cat`. `label` do arquivo = `<label>` dos blocos.

### Bloco 1b — prepare

<!-- bloco: prepare -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/prepare.json" ]]; then echo "JÁ FEITO: ${RUN}/prepare.json existe; o prepare não roda de novo. Valores gravados:"
  elif [[ "$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${PARAMS}" label)" != "${L}" ]]; then echo "PARADO: o label de PARAMETERS.json não é ${L}; nada foi feito"
  else
    OUTJSON=$("${PY}" "${PYFLAGS[@]}" "${BIND}" prepare --family "${FAMILY}" --operation "${OP}" --params "${PARAMS}" --reference "${REFERENCE}" --out "${OUT}" --mode "${MODE}"); RC=$?; echo "exit=${RC}"
    if [[ ${RC} == 0 ]]; then print -r -- "${OUTJSON}" > "${RUN}/prepare.json"; else print -r -- "${OUTJSON}"; fi
  fi
  if [[ -e "${RUN}/prepare.json" ]]; then
    SHEET=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/prepare.json" prepare_json_sha256) && is_hash "${SHEET}" && echo "folha ${SHEET}" \
     && [[ "$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/prepare.json" sheet.label)" == "${L}" ]] && echo "label ${L} confere com a folha" \
     && shasum -a 256 "${OUT}/PREPARE.json" "${OUT}/REQUEST.BOUND.json" "${OUT}/GO_SCOPE.txt" && ls -la "${OUT}" "${OUT}/.dispatch-root" \
     && "${PY}" "${PYFLAGS[@]}" -c "import json,sys;s=json.load(open(sys.argv[1]))['sheet'];print(json.dumps({k:s[k] for k in ('mode','operation','family','signature_model','review','request_sha256','source_sha256','scope_sha256','go_scope_sha256','effects_sha256','success_criterion','host_binding_sha256','command_sha256','window','transport_reference','evidence','plan_values_equal_to_the_cited_receipts','provisional_proofs','claim_root_identity')},indent=1,ensure_ascii=False))" "${RUN}/prepare.json"
    G=$("${PY}" "${PYFLAGS[@]}" -c "import json,sys;h=json.load(open(sys.argv[1]))['sheet'].get('hostops02');print(' '.join(h['dispatch_gates']) if h else '')" "${RUN}/prepare.json") \
     && [[ -n "${G}" ]] && echo "portões de envio da folha: ${G}" && [[ -z "${GATES}" ]] && echo "ATENÇÃO: o run.env não tem GATES: os blocos 6 e 9 param até ele existir (bloco 1a)"
  fi
fi
```

Conferir a olho:

- `exit=0`; `mode` `REAL`; `family` com o selo exato de ACCEPTED_SEALS.json e INDEX_BOOTSTRAP_REV5.json desta cópia; `shasum` de `PREPARE.json` igual a `folha`, e o de
  `REQUEST.BOUND.json` igual a `request_sha256`; `label ... confere com a folha`.
- `host_binding_sha256` = `226f6148…e9d2`; `command_sha256` = `6719e523…dce2`.
- `transport_reference`: `kind` `REAL`, `last_use.status` `KNOWN_COMPLETE` ou `KNOWN_PARTIAL`,
  `connection_files` com os dois booleanos `true`.
- `window.brt`: é a janela que vai ser dita ao dono; `latest_start` = fim − 80 s; no W1, `gate_span_seconds` ≤ 3600.
- `provisional_proofs`: as 17 linhas da seção 6 (a fonte e o dispatcher da família aceitaram documentos provisórios
  com esta janela e este transporte, e recusaram as variantes).
- W1: `source_sha256` `7d1df28d…79f8`, `scope_sha256` `d860347b…4b9d`. Núcleo: ler `EFFECTS.json` inteiro; em
  `evidence`, cada recibo com `source` `BOUND_SET`, `complete` `true` (ou a aceitação explícita) e
  `bound_set.mode` `REAL`; numa gravação, `review` com o `kind` e o sha256 do documento certo.
- `.dispatch-root` vazio; nenhum arquivo `*AUTHORITY*`, `*GO*` ou `DISPATCH.BOUND.json` existe ainda.

O prepare roda uma vez por diretório: um segundo recusa com `OUT_EXISTS_OR_PARENT_MISSING`.

Publicar no canal, para objeção do auditor quando o plano pedir (hashes, selo e janela em UTC; nenhum valor do
servidor). O texto de `GO_SCOPE.txt` pode ser anexado à mão: não tem valor do servidor.

<!-- bloco: publicar-pedido rede -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/request_publication_url.txt" ]]; then echo "JÁ FEITO: pedido publicado em $(cat "${RUN}/request_publication_url.txt")"
  else
    TS=$(date -u +%Y%m%dT%H%M%SZ) \
     && "${PY}" "${PYFLAGS[@]}" -c "import json,sys;p=json.load(open(sys.argv[1]));s=p['sheet'];w=s['window'];f=s['family'];print('%s (%s, %s) request bound, NOT signed: request %s ; source %s ; scope %s ; go scope %s ; sheet %s ; seal %s (%s rev %s) ; window %s .. %s UTC ; gate %s .. %s UTC ; latest start %s ; signature model %s'%(s['operation'],s['label'],s['mode'],s['request_sha256'],s['source_sha256'],s['scope_sha256'],s['go_scope_sha256'],p['prepare_json_sha256'],f['sha256sums_sha256'],f['family'],f['revision'],w['not_before'],w['not_after'],w['gate_not_before'],w['gate_not_after'],w['latest_start'],s['signature_model']))" "${RUN}/prepare.json" > "${RUN}/publish-request.${TS}.md" \
     && cat "${RUN}/publish-request.${TS}.md" \
     && { gh issue comment ${ISSUE} --repo ${REPO} --body-file "${RUN}/publish-request.${TS}.md" > "${RUN}/gh-request.${TS}.out"; echo "gh exit=$? (saída em gh-request.${TS}.out)" }
    URL=$(tail -n 1 "${RUN}/gh-request.${TS}.out" 2>/dev/null)
    is_comment_url "${URL}" && print -r -- "${URL}" > "${RUN}/request_publication_url.txt" && echo "request_publication_url $(cat "${RUN}/request_publication_url.txt")" \
     || echo "request_publication_url.txt NÃO foi escrito por este bloco: procurar o comentário no canal antes de publicar de novo"
  fi
fi
```

### Bloco 2 — a pergunta ao dono

Notificar (banner no Mac e push), depois perguntar pelo AskUserQuestion com **o texto exato de
`${OUT}/OWNER_QUESTION.txt`** (português, horas em BRT, termina em "responda exatamente: Assino"; traz o hash da
folha; numa gravação, a lista do que é criado e a linha da revisão ou da dispensa).

<!-- bloco: pergunta -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  cat "${OUT}/OWNER_QUESTION.txt"
fi
```

**Só a resposta literal `Assino` é assinatura.** No instante da resposta, rodar o bloco abaixo trocando
`<resposta>` pela resposta do dono, palavra por palavra. Ele grava a hora (por comando) e a resposta **somente**
se ela for a palavra de assinatura; com qualquer outra resposta não grava nada, e o bloco 3 não roda. Se a pergunta
for refeita (a mesma folha) e a nova resposta for `Assino`, rodar o bloco de novo com ela: a hora gravada é a
dessa resposta, nunca a de uma resposta anterior. Nunca passar uma hora ou uma resposta que o dono não deu.

<!-- bloco: resposta -->
```zsh
L=<label>; R='<resposta>'; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/owner_answer.txt" ]]; then echo "JÁ FEITO: resposta de assinatura já gravada: $(cat "${RUN}/owner_answer.txt") às $(cat "${RUN}/signed_at_utc.txt")"
  elif [[ "${R}" != "${ANSWER_WORD}" ]]; then echo "NÃO É ASSINATURA: a resposta não é literalmente a palavra de assinatura; nada foi gravado e o sign não roda"
  else
    date -u +%Y-%m-%dT%H:%M:%SZ > "${RUN}/signed_at_utc.txt" && print -r -- "${R}" > "${RUN}/owner_answer.txt" \
     && echo "resposta gravada: $(cat "${RUN}/owner_answer.txt") às $(cat "${RUN}/signed_at_utc.txt")"
  fi
fi
```

### Bloco 3 — sign

<!-- bloco: sign -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/sign.json" ]]; then echo "JÁ FEITO: ${RUN}/sign.json existe; o sign não roda de novo. Conjunto:"
  elif [[ ! -e "${RUN}/owner_answer.txt" || ! -e "${RUN}/signed_at_utc.txt" ]]; then echo "PARADO: não há resposta de assinatura gravada (bloco da resposta); o sign não roda"
  elif SHEET=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/prepare.json" prepare_json_sha256) && SIGNED=$(cat "${RUN}/signed_at_utc.txt") && ANSWER=$(cat "${RUN}/owner_answer.txt") && is_hash "${SHEET}" && is_utc_stamp "${SIGNED}"; then
    OUTJSON=$("${PY}" "${PYFLAGS[@]}" "${BIND}" sign --bound "${OUT}" --sheet-sha256 "${SHEET}" --signed-at "${SIGNED}" --owner-answer "${ANSWER}"); RC=$?; echo "exit=${RC}"
    [[ ${RC} == 0 ]] && print -r -- "${OUTJSON}" > "${RUN}/sign.json"
    print -r -- "${OUTJSON}"
  else echo "PARADO: hash da folha ou hora da resposta ilegível; o sign não rodou"
  fi
  [[ -e "${RUN}/sign.json" ]] && cd "${OUT}" && shasum -a 256 -c SHA256SUMS | grep -vc ': OK$' ; ls -la "${OUT}"
fi
```

Conferir a olho: `exit=0`, `status` `BOUND_NOT_DISPATCHED`; `prepare_json_sha256` é a folha que o dono viu;
`signed_at_utc` é a hora gravada e `owner_answer_verbatim` é `Assino`; `authority_name` e `go_name` começam por
`DUDU_`; `command_sha256` e `host_binding_sha256` iguais aos do prepare; contagem de linhas não-OK do `SHA256SUMS`
igual a `0`; `.dispatch-root` ainda vazio. O sign roda uma vez: o segundo recusa com
`BOUND_FILE_SET_OR_ALREADY_SIGNED`. Resposta que não é a palavra literal: `OWNER_ANSWER_IS_NOT_THE_SIGNATURE`,
nada escrito. O sign funciona antes da janela abrir (assinatura de véspera): nada nele depende do relógio estar
dentro dela.

### Bloco 4 — check (validação a seco, não escreve nada)

<!-- bloco: check -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  GATEARGS=(); if [[ -n "${GATES}" ]]; then GATEARGS=(--gates "${GATES}"); fi
  OUTJSON=$("${PY}" "${PYFLAGS[@]}" "${BIND}" check --bound "${OUT}" --family "${FAMILY}" "${GATEARGS[@]}"); RC=$?; echo "exit=${RC}"
  print -r -- "${OUTJSON}" > "${RUN}/check.$(date -u +%Y%m%dT%H%M%SZ).$$.json"; print -r -- "${OUTJSON}"
fi
```

Conferir a olho, **antes do bloco 6**: `exit=0`; `verdict` `VALID_WINDOW_OPEN` (ou `VALID_WINDOW_NOT_YET_OPEN`
antes da janela); `a_new_dispatcher_prepare_would_reach_the_claim_and` `CREATE_IT` com a janela aberta;
`documents_are_the_deterministic_construction`, `family_seal_and_templates_rechecked` e
`binder_unchanged_since_prepare` `true`; as 17 provas da seção 6; `final_payload_run_locally_as_this_user` com
`REFUSED` / `REQUEST_OR_EXECUTOR_UNBOUND` e stderr vazio; `attempt_phase` `NOT_PREPARED`; `wrote_nothing` `true`.

| `verdict` | Exit | Significado |
|---|---|---|
| `VALID_WINDOW_NOT_YET_OPEN`, `VALID_WINDOW_OPEN` | 0 | conjunto válido, nada reivindicado ainda |
| `VALID_BUT_PAST_LATEST_START_THE_DISPATCHER_WILL_REFUSE` | 1 | a assinatura não serve mais |
| `VALID_ALREADY_PREPARED` | 1 | o claim já existe (bloco 6 feito): um segundo prepare do dispatcher falharia; seguir para publicação e resume |
| `VALID_GO_SPENT` | 1 | `spawn.claim` existe (tentativa terminada ou de resultado desconhecido): o GO está gasto |
| `VALID_BUT_THE_CLAIM_ROOT_IS_NOT_AS_THE_DISPATCHER_LEAVES_IT` | 1 | conteúdo inesperado na raiz de uso único: parar e relatar |
| `VALID_BUT_DISPATCH_GATES_NOT_MET` | 1 | HOSTOPS02: um portão de envio da folha não foi atendido (ou `GATES` não foi dado): `dispatch_gates.failed` diz qual; não despachar |
| `VALID_BUT_NOW_IS_A_MINUTE_TO_AVOID` | 1 | HOSTOPS02: agora é um minuto a evitar (:05–:07, :10–:25, :35–:37); esperar o próximo minuto utilizável |
| `VALID_RESUME_ALLOWED_BY_THE_GATES`, `VALID_BUT_RESUME_GATES_NOT_MET`, `VALID_BUT_NOTHING_TO_RESUME` | 0, 1, 1 | HOSTOPS02, só com `--step resume` (o bloco 9 roda sozinho): portões, minuto a evitar e último início antes do resume |

As provas `dispatcher_accepts_*` param **antes** da criação exclusiva do claim; depois do bloco 6 elas continuam
dizendo "aceito até o claim", e é o `verdict` (com `window_verdict` e `attempt_phase`) que diz o estado.
O check pode ser repetido à vontade: cada saída vai para um arquivo próprio, com a hora UTC e o número do processo
do shell no nome, de modo que duas no mesmo segundo não colidem (o mesmo vale para o bloco 10).

### Bloco 5 — publicar a âncora

`config_sha256` é a âncora local, passada ao dispatcher independentemente do arquivo.

<!-- bloco: publicar-ancora rede -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/anchor_publication_url.txt" ]]; then echo "JÁ FEITO: âncora publicada em $(cat "${RUN}/anchor_publication_url.txt")"
  else
    TS=$(date -u +%Y%m%dT%H%M%SZ) \
     && "${PY}" "${PYFLAGS[@]}" -c "import json,sys;s=json.load(open(sys.argv[1]));w=s['window'];print('%s (%s) bound and signed, NOT dispatched: config %s ; payload %s (%d bytes) ; go %s ; authority %s ; request %s ; sheet %s ; signed at %s ; gate %s .. %s UTC ; latest start %s'%(s['operation'],s['mode'],s['config_sha256'],s['payload_sha256'],s['payload_bytes'],s['go_sha256'],s['authority_sha256'],s['request_sha256'],s['prepare_json_sha256'],s['signed_at_utc'],w['gate_not_before'],w['gate_not_after'],w['latest_start']))" "${RUN}/sign.json" > "${RUN}/publish-anchor.${TS}.md" \
     && cat "${RUN}/publish-anchor.${TS}.md" \
     && { gh issue comment ${ISSUE} --repo ${REPO} --body-file "${RUN}/publish-anchor.${TS}.md" > "${RUN}/gh-anchor.${TS}.out"; echo "gh exit=$? (saída em gh-anchor.${TS}.out)" }
    URL=$(tail -n 1 "${RUN}/gh-anchor.${TS}.out" 2>/dev/null)
    is_comment_url "${URL}" && print -r -- "${URL}" > "${RUN}/anchor_publication_url.txt" && echo "anchor_publication_url $(cat "${RUN}/anchor_publication_url.txt")" \
     || echo "anchor_publication_url.txt NÃO foi escrito por este bloco: procurar o comentário no canal antes de publicar de novo"
  fi
fi
```

### Bloco 6 — prepare do dispatcher: UMA vez; sai com 2 por desenho

O sucesso deste passo é exit 2 com `AWAITING_PUBLICATION_NO_SPAWN`. Decidir pelo status impresso, nunca pelo código
de saída (uma recusa também sai com 2).

O dispatcher importa três módulos irmãos pelo nome. O Python do sistema deste Mac guarda bytecode fora do
diretório (`~/Library/Caches/com.apple.python/<caminho absoluto>`), e `-B` só impede a gravação: um `.pyc` em cache
com data e tamanho iguais seria executado no lugar da fonte fixada por hash. Por isso o dispatcher roda com
`-X pycache_prefix=<diretório novo, vazio, 0700>` (criado por `mktemp -d` no bloco): sem cache para ler. O bloco
remove o diretório no fim, o que só funciona se ele continuou vazio. O payload enviado não é afetado: é lido por hash.

<!-- bloco: dispatcher-prepare -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  GATEOK=yes
  if [[ ! -e "${RUN}/dispatch-prepare.json" ]]; then
    H02=$("${PY}" "${PYFLAGS[@]}" -c "import json,sys;s=json.load(open(sys.argv[1]));h=s.get('hostops02');print('none' if h is None else ('gates' if h['dispatch_gates'] else 'nogates'))" "${OUT}/PREPARE.json") || H02=unreadable
    if [[ "${H02}" == unreadable ]]; then GATEOK=no; echo "PARADO: PREPARE.json ilegível; o prepare do dispatcher não rodou"
    elif [[ "${H02}" == gates && -z "${GATES}" ]]; then GATEOK=no; echo "PARADO: a folha lista portões de envio e o run.env não tem GATES (bloco 1a); o prepare do dispatcher não rodou"
    elif [[ "${H02}" != none ]]; then
      GATEARGS=(); if [[ -n "${GATES}" ]]; then GATEARGS=(--gates "${GATES}"); fi
      GJSON=$("${PY}" "${PYFLAGS[@]}" "${BIND}" check --bound "${OUT}" --family "${FAMILY}" "${GATEARGS[@]}"); echo "check antes do prepare do dispatcher exit=$?"
      print -r -- "${GJSON}" > "${RUN}/check-dispatch.$(date -u +%Y%m%dT%H%M%SZ).$$.json"
      if [[ "${GJSON}" != *'"verdict": "VALID_WINDOW_OPEN"'* ]]; then GATEOK=no; echo "PARADO: o check não deu VALID_WINDOW_OPEN (portão, minuto a evitar, janela ou reserva): o prepare do dispatcher não rodou (ver check-dispatch.*.json)"; fi
    fi
  fi
  if [[ -e "${RUN}/dispatch-prepare.json" ]]; then echo "JÁ FEITO: ${RUN}/dispatch-prepare.json existe; o prepare do dispatcher não roda de novo. Valores gravados:"
  elif [[ "${GATEOK}" != yes ]]; then echo "nada foi preparado: nenhum claim foi criado por este bloco"
  elif CFG=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/sign.json" config_sha256) && is_hash "${CFG}" && shasum -a 256 "${OUT}/DISPATCH.BOUND.json" && PYC=$(mktemp -d "${RUN}/pycache-prefix.XXXXXXXX"); then
    OUTJSON=$("${PY}" "${DISPATCH_PYFLAGS[@]}" -X pycache_prefix="${PYC}" "${OUT}/dispatch_once.py" --config "${OUT}/DISPATCH.BOUND.json" --config-sha256 "${CFG}" --phase prepare); RC=$?; echo "exit=${RC} (2 é o esperado)"; print -r -- "${OUTJSON}"
    rmdir "${PYC}" && echo "prefixo de cache continuou vazio e foi removido"
    [[ "${OUTJSON}" == *'"status": "AWAITING_PUBLICATION_NO_SPAWN"'* ]] && print -r -- "${OUTJSON}" > "${RUN}/dispatch-prepare.json"
  else echo "PARADO: sign.json ilegível ou hash da config inválido; o prepare do dispatcher não rodou"
  fi
  if [[ -e "${RUN}/dispatch-prepare.json" ]]; then
    INTENT=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/dispatch-prepare.json" intent_sha256) && is_hash "${INTENT}" && echo "intent ${INTENT}" \
     && shasum -a 256 "${ATTEMPT}/intent.json" && ls -la "${OUT}/.dispatch-root" "${ATTEMPT}"
  fi
fi
```

Conferir a olho: uma linha `{"config_sha256": ..., "go_sha256": ..., "intent_sha256": ..., "retry": false, "status":
"AWAITING_PUBLICATION_NO_SPAWN"}` e `exit=2`; `config_sha256` e `go_sha256` iguais aos do `sign.json`; `shasum` de
`intent.json` igual a `intent`; em `.dispatch-root`, o claim `.go-<go_sha256>.claim` e o diretório `<label>-once`
só com `intent.json`; `prefixo de cache continuou vazio e foi removido`. Este é o primeiro código que abre a chave
e o known-hosts (lê os dois com o hash fixado, antes de qualquer claim). Não contata nada.
`{"status":"REFUSED_OR_UNCERTAIN","code":"DISPATCH_REFUSED"}` com `.dispatch-root` vazio: nada foi consumido
(causas típicas: relógio fora da janela ou depois do último início; chave ou known-hosts com outro hash); entender
a causa, e o prepare pode rodar de novo. Com o claim presente: o GO está gasto para o prepare; não repetir.

### Bloco 7 — publicar o intent e pegar id e hora do comentário

<!-- bloco: publicar-intent rede -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/publication_url.txt" ]]; then echo "JÁ FEITO: intent publicado em $(cat "${RUN}/publication_url.txt")"
  else
    CFG=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/sign.json" config_sha256) && GO=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/sign.json" go_sha256) \
     && INTENT=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/dispatch-prepare.json" intent_sha256) && is_hash "${CFG}" && is_hash "${GO}" && is_hash "${INTENT}" \
     && TS=$(date -u +%Y%m%dT%H%M%SZ) \
     && print -r -- "${OP} (${L}) intent published before spawn: intent ${INTENT} ; config ${CFG} ; go ${GO}" > "${RUN}/publish-intent.${TS}.md" \
     && { gh issue comment ${ISSUE} --repo ${REPO} --body-file "${RUN}/publish-intent.${TS}.md" > "${RUN}/gh-intent.${TS}.out"; echo "gh exit=$? (saída em gh-intent.${TS}.out)" }
    URL=$(tail -n 1 "${RUN}/gh-intent.${TS}.out" 2>/dev/null)
    is_comment_url "${URL}" && print -r -- "${URL}" > "${RUN}/publication_url.txt" && echo "publication_url $(cat "${RUN}/publication_url.txt")" \
     || echo "publication_url.txt NÃO foi escrito por este bloco"
  fi
fi
```

Se não foi escrito: não publicar de novo às cegas; procurar primeiro o comentário (a publicação pode ter saído
mesmo com a saída perdida):

<!-- bloco: achar-intent rede -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/publication_url.txt" ]]; then echo "JÁ FEITO: intent publicado em $(cat "${RUN}/publication_url.txt")"
  else
    INTENT=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/dispatch-prepare.json" intent_sha256) && is_hash "${INTENT}" \
     && SINCE=$(cat "${RUN}/signed_at_utc.txt") && is_utc_stamp "${SINCE}" && TS=$(date -u +%Y%m%dT%H%M%SZ) \
     && { gh api "repos/${REPO}/issues/${ISSUE}/comments?since=${SINCE}&per_page=100" --jq ".[] | select(.body | contains(\"intent ${INTENT}\")) | .html_url" > "${RUN}/gh-intent-find.${TS}.out"; echo "gh exit=$?" }
    N=$(grep -c . "${RUN}/gh-intent-find.${TS}.out" 2>/dev/null); URL=$(head -n 1 "${RUN}/gh-intent-find.${TS}.out" 2>/dev/null)
    [[ "${N}" -ge 1 ]] && is_comment_url "${URL}" && print -r -- "${URL}" > "${RUN}/publication_url.txt" && echo "achados ${N}; publication_url $(cat "${RUN}/publication_url.txt")" \
     || echo "achados ${N:-0}; publication_url.txt NÃO foi escrito por este bloco"
  fi
fi
```

O id do comentário e a hora de criação (`created_at`), pela API:

<!-- bloco: id-e-hora rede -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/publication_ref.txt" || -e "${RUN}/published_at_utc.txt" ]]; then echo "JÁ FEITO: publication_ref $(cat "${RUN}/publication_ref.txt") published_at $(cat "${RUN}/published_at_utc.txt")"
  else
    URL=$(cat "${RUN}/publication_url.txt") && is_comment_url "${URL}" && PUBID=${URL##*issuecomment-} && [[ "${PUBID}" =~ '^[0-9]{6,20}$' ]] \
     && TS=$(date -u +%Y%m%dT%H%M%SZ) \
     && { gh api "repos/${REPO}/issues/comments/${PUBID}" --jq .created_at > "${RUN}/gh-created.${TS}.out"; echo "gh exit=$?" }
    AT=$(tail -n 1 "${RUN}/gh-created.${TS}.out" 2>/dev/null)
    is_utc_stamp "${AT}" && print -r -- "${PUBID}" > "${RUN}/publication_ref.txt" && print -r -- "${AT}" > "${RUN}/published_at_utc.txt" \
     && echo "publication_ref $(cat "${RUN}/publication_ref.txt") published_at $(cat "${RUN}/published_at_utc.txt")" \
     || echo "publication_ref.txt / published_at_utc.txt NÃO foram escritos por este bloco"
  fi
fi
```

### Bloco 8 — publish-proof

<!-- bloco: publish-proof -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/proof.json" ]]; then echo "JÁ FEITO: ${RUN}/proof.json existe; a prova não é escrita de novo. Valores gravados:"
  elif PUBID=$(cat "${RUN}/publication_ref.txt") && AT=$(cat "${RUN}/published_at_utc.txt") && is_utc_stamp "${AT}"; then
    OUTJSON=$("${PY}" "${PYFLAGS[@]}" "${BIND}" publish-proof --bound "${OUT}" --comment-id "${PUBID}" --created-at "${AT}"); RC=$?; echo "exit=${RC}"
    [[ ${RC} == 0 ]] && print -r -- "${OUTJSON}" > "${RUN}/proof.json"
    print -r -- "${OUTJSON}"
  else echo "PARADO: publication_ref.txt ou published_at_utc.txt ausente ou ilegível; a prova não foi escrita"
  fi
  if [[ -e "${RUN}/proof.json" ]]; then
    PSHA=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/proof.json" publication_proof_sha256) && is_hash "${PSHA}" && echo "prova ${PSHA}" \
     && shasum -a 256 "${OUT}/PUBLICATION.PROOF.json" && ls -l "${OUT}/PUBLICATION.PROOF.json"
  fi
fi
```

Conferir a olho: `exit=0`, `PROOF_WRITTEN_NOT_DISPATCHED`; `intent_sha256` igual ao do bloco 6; `published_at`
não anterior a `intent_started_at`; arquivo 0600 com o hash impresso. O dispatcher exige
`not_before <= intent.started_at <= published_at <= agora`: por isso se usa a hora de criação do comentário.
A prova nunca é sobrescrita; uma prova corrigida (só antes do resume) leva o nome seguinte: acrescentar
`--name PUBLICATION.PROOF.R2.json`. Publicar o hash da prova no canal:

<!-- bloco: publicar-prova rede -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if [[ -e "${RUN}/proof_publication_url.txt" ]]; then echo "JÁ FEITO: hash da prova publicado em $(cat "${RUN}/proof_publication_url.txt")"
  else
    TS=$(date -u +%Y%m%dT%H%M%SZ) \
     && "${PY}" "${PYFLAGS[@]}" -c "import json,sys;s=json.load(open(sys.argv[1]));print('%s (%s) publication proof written, resume NOT run: proof %s ; intent %s ; config %s ; go %s ; publication ref %s ; published at %s ; latest start %s'%(s['operation'],s['mode'],s['publication_proof_sha256'],s['intent_sha256'],s['config_sha256'],s['go_sha256'],s['publication_ref'],s['published_at'],s['latest_start']))" "${RUN}/proof.json" > "${RUN}/publish-proof.${TS}.md" \
     && cat "${RUN}/publish-proof.${TS}.md" \
     && { gh issue comment ${ISSUE} --repo ${REPO} --body-file "${RUN}/publish-proof.${TS}.md" > "${RUN}/gh-proof.${TS}.out"; echo "gh exit=$? (saída em gh-proof.${TS}.out)" }
    URL=$(tail -n 1 "${RUN}/gh-proof.${TS}.out" 2>/dev/null)
    is_comment_url "${URL}" && print -r -- "${URL}" > "${RUN}/proof_publication_url.txt" && echo "proof_publication_url $(cat "${RUN}/proof_publication_url.txt")" \
     || echo "proof_publication_url.txt NÃO foi escrito por este bloco: procurar o comentário no canal antes de publicar de novo"
  fi
fi
```

### Bloco 9 — resume: UMA vez; o único passo que contata o servidor

Escolher um momento sem deploy, sem workflow agendado e sem o scan diário (um contêiner que sobe ou cai durante a
leitura dá PARCIAL). Evitar HH:05–07, HH:35–37 e HH:10–25. Tem de começar até `latest_start`. Leva até 80 s (o
watchdog), mais alguns segundos de finalização local. **Rodar com o timeout da ferramenta em 300000 ms (5 min),
em primeiro plano, e não interromper**: o padrão da ferramenta, 120 s, deixa pouca folga, e um bloco cortado no meio
deixa `spawn.claim` sem resultado. O bloco só inicia o resume se `intent.json` existe na tentativa deste label e
`spawn.claim` não existe; usa o mesmo prefixo de cache vazio do bloco 6.

<!-- bloco: resume host -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  GATEOK=yes
  H02=$("${PY}" "${PYFLAGS[@]}" -c "import json,sys;s=json.load(open(sys.argv[1]));h=s.get('hostops02');print('none' if h is None else ('gates' if h['dispatch_gates'] else 'nogates'))" "${OUT}/PREPARE.json") || H02=unreadable
  if [[ "${H02}" == unreadable ]]; then GATEOK=no; echo "PARADO: PREPARE.json ilegível; o resume não roda"
  elif [[ "${H02}" == gates && -z "${GATES}" ]]; then GATEOK=no; echo "PARADO: a folha lista portões de envio e o run.env não tem GATES; o resume não roda"
  elif [[ "${H02}" != none ]]; then
    GATEARGS=(); if [[ -n "${GATES}" ]]; then GATEARGS=(--gates "${GATES}"); fi
    GJSON=$("${PY}" "${PYFLAGS[@]}" "${BIND}" check --bound "${OUT}" --family "${FAMILY}" "${GATEARGS[@]}" --step resume); echo "check --step resume exit=$?"
    print -r -- "${GJSON}" > "${RUN}/check-resume.$(date -u +%Y%m%dT%H%M%SZ).$$.json"
    if [[ "${GJSON}" != *'"verdict": "VALID_RESUME_ALLOWED_BY_THE_GATES"'* ]]; then GATEOK=no; echo "PORTÃO ANTES DO RESUME NÃO LIBERADO (portão, minuto a evitar ou último início): o resume não roda (ver check-resume.*.json)"; fi
  fi
  if [[ "${GATEOK}" == yes ]] && CFG=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/sign.json" config_sha256) && PSHA=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/proof.json" publication_proof_sha256) \
     && PROOF=$("${PY}" "${PYFLAGS[@]}" "${PICK}" "${RUN}/proof.json" publication_proof_path) && is_hash "${CFG}" && is_hash "${PSHA}" \
     && [[ -f "${ATTEMPT}/intent.json" && ! -e "${ATTEMPT}/spawn.claim" ]] && PYC=$(mktemp -d "${RUN}/pycache-prefix.XXXXXXXX"); then
    OUTJSON=$("${PY}" "${DISPATCH_PYFLAGS[@]}" -X pycache_prefix="${PYC}" "${OUT}/dispatch_once.py" --config "${OUT}/DISPATCH.BOUND.json" --config-sha256 "${CFG}" --phase resume --publication-proof "${PROOF}" --publication-proof-sha256 "${PSHA}"); RC=$?; echo "exit=${RC}"; print -r -- "${OUTJSON}"
    print -r -- "${OUTJSON}" > "${RUN}/resume.$(date -u +%Y%m%dT%H%M%SZ).json"; rmdir "${PYC}"
  else echo "RESUME NÃO INICIADO por este bloco: uma guarda falhou (hash ilegível, prova ausente, intent.json ausente ou spawn.claim já existe). Nada foi enviado."
  fi
  ls -la "${ATTEMPT}"
fi
```

| Status impresso | Exit | Significado | GO gasto? |
|---|---|---|---|
| `KNOWN_COMPLETE` | 0 | toda observação feita (leitura) / critério de sucesso atingido (gravação) | sim |
| `KNOWN_PARTIAL` | 2 | **resultado válido, não falha**: o recibo traz o que foi lido ou feito | sim |
| `KNOWN_REFUSAL` | 2 | o payload recusou no servidor antes de observar ou gravar | sim |
| `UNCERTAIN` | 2 | timeout, erro de transporte, stderr não vazio, recibo não vinculado | sim |
| `REFUSED_OR_UNCERTAIN` / `DISPATCH_REFUSED` | 2 | o dispatcher local recusou; se `spawn.claim` existe o GO está gasto, se não existe nenhuma tentativa foi feita | ver `spawn.claim` |

Gravação que terminou em qualquer coisa que não o critério de sucesso: o estado do servidor é estabelecido por uma
leitura (precheck ou readback) com GO próprio, nunca por uma segunda tentativa.

### Bloco 10 — status

<!-- bloco: status -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  OUTJSON=$("${PY}" "${PYFLAGS[@]}" "${BIND}" status --bound "${OUT}"); RC=$?; echo "exit=${RC}"
  print -r -- "${OUTJSON}" > "${RUN}/status.$(date -u +%Y%m%dT%H%M%SZ).$$.json"; print -r -- "${OUTJSON}"
fi
```

`exit=0` só com recibo verificado (COMPLETE ou PARTIAL): `exit.json` bate com os bytes guardados de stdout e
stderr e vincula esta config, este request e este GO; stderr vazio; o recibo tem o esquema da operação, os vínculos
de hash (request, authority, GO, payload, vínculo do servidor) e o selo `metadata_sha256` correto; o status dele
combina com o do transporte. Para o núcleo: `outcome`, `success_criterion_met` e as contagens de chamadas.
O status imprime códigos, contagens e hashes, nunca um valor lido no servidor. Os `findings` do W1 são códigos, mas
dizem como o servidor está: por padrão sai só `findings_count`; `--show-findings` lista os códigos (leitura local;
no canal, só o que o auditor precisar). O conteúdo do recibo fica em `stdout.private.json`, 0600, onde está.
Antes do fim: `NOT_PREPARED`, `PREPARED_AWAITING_PUBLICATION`, `PREPARED_PROOF_WRITTEN_RESUME_NOT_RUN`,
`SPAWN_CLAIMED_NO_RESULT` (tentativa consumida, resultado desconhecido: nunca repetir).
`claim_root_read` diz qual raiz de uso único foi lida (seção 0, "Onde fica o diretório vinculado").

### Bloco 11 — cópia para o diretório durável

<!-- bloco: arquivar -->
```zsh
L=<label>; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  DEST="${ARCHIVE:-${W}}/once-${L}" && NAME=$(basename "${OUT}") && mkdir -p "${DEST}" && chmod 700 "${DEST}" \
   && { [[ "${OUT}" == "${DEST}/${NAME}" ]] || { [[ ! -e "${DEST}/${NAME}" ]] && cp -Rp "${OUT}" "${DEST}/" } } \
   && find "${RUN}" -maxdepth 1 -type f -exec cp -np {} "${DEST}/" \; \
   && cd "${DEST}/${NAME}" && shasum -a 256 -c SHA256SUMS | grep -vc ': OK$' ; diff -r "${OUT}" "${DEST}/${NAME}" && echo "cópia idêntica" ; "${PY}" "${PYFLAGS[@]}" "${BIND}" status --bound "${DEST}/${NAME}" | grep -E '"(status|verified|bound_set_is_a_relocated_copy|claim_root_read)"'
fi
```

Conferir a olho: `0` linhas não-OK; `cópia idêntica`; o `status` da cópia com o mesmo `status` e `verified` do bloco
10 e `bound_set_is_a_relocated_copy` `true` (opção A) ou `false` (opção B). Na opção A, depois de um resume
terminado, `claim_root_read` é `OF_THIS_COPY_WHICH_HOLDS_A_FINISHED_ATTEMPT`: são os bytes da cópia que foram
conferidos. Nada é apagado do scratchpad. O conjunto arquivado é o que um pedido posterior cita em `evidence`
(`"bound"`): o original ou a cópia, os dois servem.

## 4. Códigos de saída

| Comando | 0 | 1 | 2 |
|---|---|---|---|
| `bind_once.py prepare / sign / publish-proof / rehearsal-reference / sealed-copy` | feito | — | `REFUSED` |
| `bind_once.py check` | válido, janela aberta ou ainda não aberta, nada reivindicado (e, HOSTOPS02, os portões da folha atendidos); com `--step resume` (K10): `VALID_RESUME_ALLOWED_BY_THE_GATES` | válido, mas este GO não serve para um novo prepare do dispatcher: passou do último início, já preparado ou gasto, ou um portão de envio não atendido | `REFUSED` |
| `bind_once.py status` | recibo verificado | sem recibo verificado (inclui antes do resume) | `REFUSED` |
| `dispatch_once.py --phase prepare` | nunca | nunca | sempre: `AWAITING_PUBLICATION_NO_SPAWN` (sucesso) ou `DISPATCH_REFUSED` |
| `dispatch_once.py --phase resume` | só `KNOWN_COMPLETE` | nunca | `KNOWN_PARTIAL`, `KNOWN_REFUSAL`, `UNCERTAIN`, `DISPATCH_REFUSED` |

## 5. O que nunca se repete nem se toca

1. **resume, depois que `spawn.claim` existe**, qualquer que tenha sido a saída. Uma tentativa adicional exige decisão/autorização novas e exatas, quando permitida pelo contrato. Novo request, folha, assinatura, GO ou diretório não reabre o claim BOOT de época/slot consumido ou possivelmente criado; não há retry inferido.
2. **prepare do dispatcher, depois que o claim existe.**
3. **Nunca rodar ssh, o payload final ou o comando remoto à mão**, nem o transporte fora de
   `dispatch_once.py --phase resume`.
4. **Nunca passar ao sign uma hora ou uma resposta que o dono não deu**, nem o hash de outra folha. Só a palavra
   literal `Assino` é assinatura.
5. **Nunca um conjunto de ensaio para o servidor real**, nem o contrário: o binder recusa nos dois sentidos
   (`REHEARSAL_SET_WITH_REAL_TRANSPORT`, `REAL_SET_WITH_REHEARSAL_TRANSPORT`, `REHEARSAL_DIRECTORY_NAME`,
   `REAL_SET_IN_REHEARSAL_DIRECTORY`, `OWNER_MODE_MISMATCH`), e também nos recibos citados
   (`EVIDENCE_SET_OF_THE_OTHER_MODE`, `EVIDENCE_RECEIPT_OF_ANOTHER_HOST`). Não renomear diretórios para contornar.
6. **Nunca rodar o dispatcher a partir de uma cópia do conjunto**, nem sem o prefixo de cache vazio dos blocos 6 e 9.

## 6. As 17 provas (`provisional_proofs` no prepare, `proofs` no check)

O binder roda o `authenticate()` da própria fonte e o `execute(phase='prepare')` do próprio dispatcher da família,
com relógio injetado, até a criação do claim, exclusive (o `os` do dispatcher levanta uma parada no primeiro
`open` que cria; a chave e o known-hosts são conferidos só por `lstat`). Valores esperados, sempre estes:

| Prova | Valor |
|---|---|
| `source_accepts_at_not_before`, `source_accepts_at_latest_start` | `ACCEPTED` |
| `source_refuses_before_the_window`, `source_refuses_at_not_after` | `OUTSIDE_GO_WINDOW` |
| `source_refuses_this_user` | `REQUEST_OR_EXECUTOR_UNBOUND` |
| `source_refuses_unsigned_authority` | `AUTHORITY_UNBOUND` |
| `source_refuses_unsigned_go` | `GO_UNBOUND` |
| `dispatcher_accepts_at_not_before`, `dispatcher_accepts_at_latest_start` | `ACCEPTED_UP_TO_THE_CLAIM` |
| `dispatcher_refuses_before_the_window`, `dispatcher_refuses_at_not_after` | `DISPATCH_WINDOW` |
| `dispatcher_refuses_after_latest_start` | `WINDOW_WITH_WATCHDOG` |
| `dispatcher_refuses_unsigned_go`, `dispatcher_refuses_the_template_go` | `GO_UNSIGNED` |
| `dispatcher_refuses_unsigned_authority` | `AUTHORITY_UNSIGNED` |
| `dispatcher_refuses_unbound_config` | `DISPATCH_UNBOUND` |
| `dispatcher_refuses_another_payload` | `FINAL_BUNDLE_BYTES` |

Uma prova com outro valor é recusa do binder (`PROOF_FAILED_<NOME>`), antes de pedir a assinatura (prepare) ou antes
de escrever qualquer documento assinado (sign).

## 7. Recusas mais prováveis e o que fazer

| Código | Causa | O que fazer |
|---|---|---|
| `FAMILY_SEAL_NOT_ACCEPTED` | o selo da família não está em `ACCEPTED_SEALS.json` | família nova ou revisão nova: acrescentar o selo por edição deliberada, refazer o manifesto do binder, publicar |
| `FAMILY_HASH`, `FAMILY_FILE_SET` | arquivo da família mudou, sobrou ou falta | não vincular; restaurar a família selada |
| `DATE_NOT_IN_FAMILY_SCOPE` | a data UTC da janela não é da família | janela errada, ou é preciso bytes novos |
| `WINDOW_OVER_THE_READ_CAP` | janela do W1 maior que 3600 s | encurtar a janela; uma leitura por janela de até uma hora |
| `GATE_SPAN_OVER_FAMILY_CAP` | portão maior que 900 s (gravação) ou 3600 s (leitura) | encurtar, ou usar `gate_not_before`/`gate_not_after` |
| `WINDOW_CROSSES_UTC_MIDNIGHT` | a janela atravessa 21:00 BRT | dividir em duas execuções |
| `WINDOW_ALREADY_UNUSABLE` | agora já passou do último início | nova janela; se já estava assinado, nova assinatura |
| `SIGNATURE_MODEL_NOT_IMPLEMENTED` | `signature_model` `GRID` ou `WEEK` | esses modelos não existem aqui; pedir a resposta individual do dono (`IND`) ou esperar o modelo ser construído |
| `PARAMETERS_FREE_TEXT` | `purpose_pt` ou `owner_summary_pt` com quebra de linha, caractere de controle, a palavra de assinatura ou 64 hex | reescrever em uma linha |
| `REVIEW_OR_WAIVER_MISSING_FOR_A_WRITE`, `REVIEW_OR_WAIVER_INVALID`, `REVIEW_OR_WAIVER_DOCUMENT_UNREADABLE` | gravação sem `review`, com `kind` errado ou sem o documento | apontar o parecer do Codex ou a decisão de dispensa do dono |
| `EVIDENCE_OF_A_REAL_REQUEST_MUST_BE_A_BOUND_SET` | pedido real citando arquivo solto | citar o diretório vinculado da execução (`"bound"`) |
| `EVIDENCE_SET_<CÓDIGO>` | o conjunto citado não confere (o código é o que o `status` daria) | conferir o conjunto citado com `status`; não editar nada |
| `EVIDENCE_SET_WITHOUT_A_VERIFIED_RECEIPT` | o conjunto citado não terminou com recibo verificado | citar a execução certa; uma recusa remota ou um resultado incerto não é evidência |
| `EVIDENCE_RECEIPT_OF_ANOTHER_HOST`, `EVIDENCE_SET_OF_THE_OTHER_MODE`, `EVIDENCE_SET_OF_ANOTHER_SEAL`, `EVIDENCE_SET_OF_ANOTHER_OPERATION`, `EVIDENCE_RECEIPT_SCHEMA`, `EVIDENCE_RECEIPT_OPERATION`, `EVIDENCE_RECEIPT_OF_OTHER_BYTES`, `EVIDENCE_OPERATION_NOT_IN_THIS_FAMILY` | o recibo citado não é desta operação, desta família (dos bytes selados dela), deste servidor ou deste modo | citar o recibo certo |
| `EVIDENCE_RECEIPT_NOT_COMPLETE` | recibo citado parcial | refazer a leitura; ou, decidido com o dono, `"accept_not_complete": true` (aparece na pergunta) |
| `PLAN_VALUE_NOT_THE_ONE_OF_THE_CITED_RECEIPT`, `PLAN_VALUE_WITHOUT_ITS_SINGLE_CITED_RECEIPT`, `CITED_PRECHECKS_OF_DIFFERENT_BOOTS` | um valor do plano não é o do recibo citado, ou não há exatamente um recibo daquela operação | copiar por ponteiro do recibo certo; citar um só precheck, o do boot da gravação |
| `FAMILY_REFUSES_THE_REQUEST_<CÓDIGO>` | o `authenticate()` da família recusou o request | o código é o da família (seção 3.4 do contrato do HOSTOPS01, ou a lista do W1); corrigir os parâmetros |
| `SSH_REFERENCE_CHANGED_SINCE_LAST_USE` | chave ou known-hosts mexidos depois do último uso | parar e relatar; não tocar nos arquivos |
| `TRANSPORT_REFERENCE_NOT_AN_EXECUTED_CONFIG` | a referência não é de um conjunto executado (ou foi editada) | apontar `REFERENCE` para um `DISPATCH.BOUND.json` que rodou |
| `SHEET_IS_NOT_THE_ONE_THE_OWNER_SAW` | o hash dado ao sign não é o da folha em disco | conferir `prepare.json`; nunca "consertar" a folha |
| `SHEET_WINDOW_NOT_DERIVED_FROM_ITS_UTC_FIELDS`, `SHEET_FIELD_NOT_DERIVED_FROM_THE_BOUND_FILES`, `OWNER_QUESTION_CHANGED` | a folha ou a pergunta em disco não são as que o prepare escreveu | parar e relatar; novo prepare em outro diretório |
| `OWNER_ANSWER_IS_NOT_THE_SIGNATURE` | a resposta passada ao sign não é a palavra literal | não é assinatura; nada a fazer no sign |
| `BOUND_SET_HOLDS_A_DIRECTORY_THAT_IS_NOT_ITS_OWN` | há um diretório a mais no conjunto (por exemplo `__pycache__`) | parar e relatar; não apagar para "fazer passar": descobrir quem o criou |
| `BINDER_CHANGED_SINCE_PREPARE` | binder ou selos editados depois do prepare | novo prepare, nova folha, nova pergunta |
| `PUBLISHED_BEFORE_THE_INTENT` | `created_at` anterior ao intent | usar a hora de criação do comentário certo |
| `CORE_NOT_FOUND`, `CORE_SEAL_NOT_ACCEPTED`, `CORE_FILE_SET`, `CORE_HASH`, `CORE_SUMS_INVALID`, `CORE_GENERATION_NOT_THE_SOURCES` | HOSTOPS02: o núcleo ao lado da operação não é o selado e aceito | refazer a cópia selada (10.1); núcleo novo = selo novo em `ACCEPTED_SEALS.json` |
| `CORE_ASSEMBLY_CHECK_FAILED`, `ASSEMBLY_RECORD_NOT_THE_BUILD` | o `build/` da operação não é o que o núcleo monta, ou o `ASSEMBLY.json` não descreve os bytes | não vincular; relatar ao autor |
| `EVIDENCE_FAMILY_NOT_AN_ACCEPTED_SEAL`, `EVIDENCE_OPERATION_NOT_IN_THIS_FAMILY` | o item de evidência aponta uma família não aceita, ou falta `family` para uma operação de outra família | corrigir `family` do item |
| `BIND_INPUTS_INVALID`, `BIND_INPUT_UNREADABLE`, `BIND_INPUT_NOT_USED`, `PLAN_INPUT_INVALID`, `PLAN_MEMBER_NOT_FROM_ITS_INPUT_FILE` | arquivo de entrada não previsto, ilegível, sobrando, marcador errado, ou membro digitado | `inputs` e marcadores `$input` como nos modelos |
| `GATE_WINDOW_ONLY_IN_MINUTES_TO_AVOID` | o portão só tem minutos a evitar | outra janela |
| `CATALOG_*`, `PROVISION_LEDGER_ROW_NOT_FOUND`, `RETENTION_TAG_NOT_THE_SIGNED_IMAGE`, `RELEASE_TREE_*`, `SCRIPT_NOT_THE_READMES`, `EPOCH_NOT_THE_RELEASES`, `LINUX_JOB_RECORD_*` | K2a: linhas, etiqueta, árvore da release ou registro do job Linux | conferir os recibos citados e os arquivos dados |
| `RELEASE_EVIDENCE_INCOMPLETE`, `RELEASE_NOT_VERIFIED_BY_A_FULL_PRE`, `RELEASE_PARENT_NOT_THE_ONE_THE_PRE_READ`, `RELEASE_FIELDS_<código>`, `RELEASE_MEMBER_NOT_THE_TOOLS`, `LINUX_PROOF_*`, `RELEASE_SUNDAY_*`, `BINDING_TOOL_MISSING` | K10: evidência (S1, A3, B1, W1, M2p), release, prova Linux ou portão de domingo | o código diz qual; `RELEASE_FIELDS_*` é a recusa da ferramenta `release_fields.py` |
| `READBACK_EVIDENCE_WITHOUT_A_BOOT`, `IMAGE_*`, `PLAN_ROWS_NOT_THE_ROWS_OF_A_CITED_RECEIPT`, `REVISION_NOT_THE_RELEASES`, `SIBLINGS_NOT_THE_SEALED_SIBLINGS`, `RELEASE_PLACE_NOT_THE_SIBLINGS`, `LIMITS_NOT_THE_SIBLINGS_FLOORS` | K11: boot, imagem/revisão, linhas sem recibo, release, irmãs | linhas nulas (observadas) ou copiadas de um recibo citado |
| `ACTIVATE_*`, `LIVE_PARENT_NOT_ACCEPTABLE_TO_A_WRITE`, `POLICY_NOT_VERIFIED_AT_THIS_GATE`, `OVERRIDE_FILE_NOT_THE_ONE_ACTIVATE_WRITES` | K6a: o M2p citado não é o PRE completo com linhas, ou o pedido não é o que ele renderizou, ou o portão não está em `valid_at` | citar o M2p certo; janela no instante verificado |
| `SPARE_*` | reserva: principal não assinado, de outra operação, com outros efeitos, janela antes do fim do principal, raiz sumida, já preparado, ou já tem reserva (`SPARE_ALREADY_BOUND_FOR_THIS_PRIMARY`) | 10.5 |
| `REVIEW_DOCUMENT_DOES_NOT_NAME_THESE_BYTES`, `OWNER_WAIVER_NOT_A_SIGNED_RECORD_FOR_THESE_BYTES`, `REVIEW_OR_WAIVER_MISSING_FOR_A_CONTAINER_RUN` | HOSTOPS02: o parecer não nomeia o selo e o programa destes bytes; a dispensa não é um registro do dono, anterior, destes bytes; o K11 sem `review` | apontar o parecer certo, ou a decisão registrada do dono (contrato selado da família e parâmetros atuais) |
| `LINUX_JOB_RECORD_NOT_OF_THESE_BYTES`, `SIBLINGS_TESTS_*`, `WORKER_OR_IMAGE_NOT_THE_ONES_OF_THE_CITED_READ`, `RELEASE_HOST_EVIDENCE_A4_NOT_CITED_AND_NO_REASON` | registro do job Linux de outros bytes; registro das irmãs ausente (REAL) ou de outros selos; trabalhador ou imagem diferentes da leitura W1 citada; K10 sem o A4 e sem motivo | contrato selado da família e parâmetros atuais |
| `README_COMMAND_NOT_FOUND`, `DOCKER_ARGUMENTS_NOT_THE_READMES`, `REHEARSAL_RECEIPT_NOT_THE_ONE_A9_NEEDS` | K2a: o README da árvore não tem um bloco de comando legível, ou o comando dos efeitos não é o dele; o A6 dado ao A9 não é destes bytes, deste boot, desta imagem, deste script ou deste caminho, ou não está completo | conferir a árvore e o A6 |
| `CATALOG_WITHOUT_THE_CITED_4B_RECEIPT`, `CATALOG_4B_RECEIPT_NOT_ONE`, `CATALOG_4B_RECEIPT_NOT_THE_COMPLETE_REAL_ONE`, `CATALOG_EXPECTATION_NOT_THE_CITED_4B` | HOSTOPS01 readback/install: catálogo sem o A9 citado (REAL), dois recibos K2a, o recibo do ensaio ou um parcial, ou `NOT_YET` com o A9 citado | contrato selado da família e parâmetros atuais, HOSTOPS01 |
| `SEALED_COPY_SOURCE_HOLDS_A_SUPERSEDED_SEAL` | uma fonte da cópia selada tem um dos o conjunto completo do registro25 com outro selo | usar só a cópia durável (10.1) |
| `GATES_*`, `STEP_RESUME_NOT_FOR_THIS_OPERATION`, `BINDING_TOOL_NOT_THE_ONE_OF_THE_PREPARE`, `CITED_RECEIPTS_NOT_FOUND_AGAIN` | `check --gates`: arquivo inválido, conjunto sem portões, família ausente, ferramenta mudada, recibos citados movidos | 10.4 |
| `SEALED_COPY_SOURCE_NOT_FOUND`, `SEALED_COPY_FILE_NOT_FOUND` | nenhuma fonte tem a operação, o núcleo ou um arquivo com o hash selado | dar a fonte que ainda tem os bytes selados |

## 8. Ensaio

Os dois comandos, como rodam (caminhos absolutos; o carimbo vem do relógio, por comando):

```zsh
L=ensaios-runtime; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
TS=$(date -u +%Y%m%dT%H%M%SZ)
if create_external_private_directory "${REHEARSAL_BASE}"; then
"${PY}" "${PYFLAGS[@]}" "${BIND}" --run-reviewed-tool rehearse w1 --family "${W1_FAMILY}" --workspace "${REHEARSAL_BASE}/rehearsal-w1-${TS}" --real-reference "${W}/hostfacts01-fable-20261002/bound/DISPATCH.BOUND.json"; echo "exit=$?"
"${PY}" "${PYFLAGS[@]}" "${BIND}" --run-reviewed-tool rehearse precheck --family "${HOSTOPS_FAMILY}" --workspace "${REHEARSAL_BASE}/rehearsal-precheck-${TS}"; echo "exit=$?"
"${PY}" "${PYFLAGS[@]}" "${BIND}" --run-reviewed-tool runbook-tests "${REHEARSAL_BASE}/rehearsal-runbook-${TS}" "${W1_FAMILY}"; echo "exit=$?"
for K in catalog readback release activate; do "${PY}" "${PYFLAGS[@]}" "${BIND}" --run-reviewed-tool rehearse hostops02-${K} --hostops02 "${HOSTOPS02_SOURCE}" --hostops01 "${HOSTOPS_FAMILY}" --w1 "${W1_FAMILY}" --workspace "${REHEARSAL_BASE}/rehearsal-hostops02-${K}-${TS}"; echo "exit=$?"; done
else print -r -- "PARADO: diretório externo de ensaios não pôde ser criado"; fi
fi
```

Cada ensaio trabalha numa cópia de rascunho da família, com transporte falso (alvo no domínio reservado `.invalid`,
arquivos-marcador no lugar da chave), dono `REHEARSAL_NOT_THE_OWNER`, resposta `REHEARSAL_NO_OWNER_ANSWER` (a
palavra `Assino` é recusada num conjunto de ensaio), e deixa `TRANSCRIPT.json`.
W1: prepare → sign com hora sintética → check → prepare do dispatcher pela linha de comando real, com o prefixo de
cache vazio (exit 2) → check de novo (`VALID_ALREADY_PREPARED`, exit 1) → publish-proof → resume com o transporte
**substituído** pelo arnês local da família (a fonte no servidor emulado de `test_w1_preflight_once.py`; o recibo
passa pelos bytes revisados do transporte com um filho local) → status → check (`VALID_GO_SPENT`).
HOSTOPS02 (`hostops02-catalog`, `-readback`, `-release`, `-activate`): no próprio processo, com relógios injetados nos instantes
do plano (as operações são datadas de 02/10 a 05/10), cópia selada, recibos citados produzidos pelas fontes seladas das
operações citadas nos servidores emulados das suas famílias, e cada conjunto até o recibo verificado: prepare → sign
(marcador) → check (com os portões, inclusive o parecer sintético do conjunto vinculado; e o veredito de um minuto a
evitar) → check antes do prepare do dispatcher (bloco 6) → prepare do dispatcher → publish-proof → check `--step resume`
(bloco 9) → resume com a fonte no servidor emulado da própria operação e a linha passando pelos bytes revisados do
transporte com um filho local → status. A cópia selada vem só da cópia durável (`families desta própria cópia candidata`). Só
`check` e `status` passam também pela linha de comando (relógio real).
Precheck: até o prepare do dispatcher, e para. `--real-reference` só serve para mostrar que o binder recusa um
transporte real num ensaio. O terceiro comando roda literalmente os blocos zsh deste runbook que não são `host`
nem `manual`; os blocos `rede` rodam com um `gh` **falso** (um script do próprio ensaio, no `PATH` só dele, que não
contata nada e devolve uma URL e uma hora no formato que os blocos leem). Todos os blocos, inclusive o do resume,
passam por `zsh -n` (só sintaxe).

## 9. O que só uma execução real prova

- O `resume` pela linha de comando com ssh de verdade, e o recibo de um servidor de verdade. O ensaio nunca inicia
  o ssh.
- Os blocos com `gh` contra o GitHub de verdade (publicação do pedido, da âncora, do intent, da prova; id e
  `created_at`). No ensaio eles rodam com um `gh` falso. O binder não confere que o comentário existe.
- Que a chave e o known-hosts ainda têm os hashes fixados: o binder só faz `lstat`; quem lê é o prepare do
  dispatcher.
- A resposta do dono: o binder grava o que lhe é dito, e só aceita a palavra literal.
- O documento de revisão ou de dispensa: no HOSTOPS01 o binder só calcula o hash dele; no HOSTOPS02 confere que ele nomeia,
  como texto, o selo e o programa destes bytes (e, na dispensa, que é um registro de decisão do dono), mas o veredito escrito
  nele é a Fable que lê.
- Os requests das quatro operações do HOSTOPS01 com recibos reais: os testes vinculam precheck, provision,
  install_units e readback em modo REAL contra uma referência executada **sintética**, cada um citando o conjunto
  vinculado do anterior, e rodam o resume no servidor emulado da própria família; nenhum recibo real de precheck ou
  provision existe ainda. Que as linhas e os identificadores copiados sejam os do servidor no boot da gravação, só
  o precheck real diz.
- Os valores do plano que a tabela `PLAN_SOURCES` não cobre (layout, linhas do volume de dados, identidades das
  unidades, catálogo): o binder não os compara com os recibos.
- Três coisas que a pergunta mostra ao dono vêm do prepare e não são recalculadas pelo `sign` a partir dos arquivos
  do conjunto: o resultado e a completude de cada recibo citado, o sha256 do documento de revisão ou dispensa, e o
  selo da família (este é recalculado pelo `check --family` do bloco 4, antes do bloco 6). A janela, a finalidade, o
  modelo de assinatura, as contagens de candidatos, o tipo de revisão e os hashes de request, fonte, escopo e
  efeitos são recalculados. O bloco 3 só passa ao `sign` o hash que o prepare imprimiu (`prepare.json`): uma folha
  editada depois tem outro hash e é recusada.
- Que a frase de escopo gerada para o GO do W1 (`GO_SCOPE.txt`: moldura fixa em volta de citações do contrato e
  dos `SIDE_EFFECTS` da fonte) é a que o auditor e o dono aceitam: ninguém além do autor a leu.
- Leituras em grade (GRID) e assinatura semanal (WEEK): não existem neste binder.
- HOSTOPS02: que as operações selecionadas rodem no servidor como nos servidores emulados; os ensaios e os testes usam recibos
  sintéticos (produzidos pelas fontes seladas nos emuladores e ligados ao servidor do ensaio), relógios injetados e, para
  as linhas do volume de dados, os números dos emuladores do HOSTOPS (o emulador do W1 numera os dispositivos de outro
  jeito: o ensaio troca as três linhas antes de selar o recibo de novo). Os junit da prova Linux dos testes são entradas
  de teste, nunca prova. O registro do job Linux do K2a, do K11 e do K6a e o documento de revisão: o binder calcula o hash e
  confere que eles nomeiam estes bytes (contrato selado da família e parâmetros atuais); o conteúdo além disso é da Fable.

Cada source do ambiente operativo cria um cache novo e vazio em TMPDIR. Esses diretórios permanecem na estação; não são saídas operativas nem ficam na cópia selada. O filho dispatcher não reconfere a identidade: o source do bloco a confere antes, com escopo distinto dos hashes/gates próprios do conjunto.

## 10. Cópia selada do registro25 antes do primeiro prepare

### 10.1 A cópia selada do registro25 — antes do primeiro prepare

HOSTOPS02_SOURCE nomeia somente families desta cópia candidata. HOSTOPS02_COPY é o caminho fixo ${W}/hostops02-sealed-registry25-78eb4ab2. BIND_WORK_ROOT e REFERENCE permanecem na mesma raiz W; a antiga hostops02-sealed não é reutilizada. O destino novo tem de estar ausente: diretório, arquivo, link e link quebrado impedem esta receita antes da invocação do binder. Não mover, apagar ou trocar o destino para contornar a recusa; relatar HOLD. Depois de criada e conferida, a cópia válida pode ser usada pelos demais blocos, sem repetir esta receita. Não usar fonte antiga de quatro famílias, cópia preparada anterior ou árvore com selo substituído. O bloco manual abaixo faz apenas a cópia local quando o operador estiver autorizado; não transporta nem executa programa no host. Ele não foi executado nesta correção.

<!-- bloco: sealed-copy-registry25 manual -->
```manual
L=sealed-copy-bootstrap; if source "${BIND_CANDIDATE_ROOT:?}/bind/runbook_env.zsh"; then
  if require_new_hostops02_copy; then
    "${PY}" "${PYFLAGS[@]}" "${BIND}" sealed-copy --out "${HOSTOPS02_COPY}" --source "${HOSTOPS02_SOURCE}"
  fi
fi
```

Conferir SEALED_COPY_WRITTEN,23famílias/cinco núcleos e registro78eb exatos; a contagem atual de arquivos consta no índice próprio e files_taken_from_a_later_source precisa ficar vazio. Cada família identifica o próprio núcleo: BOOT usa core_bootstrap_identity, K3-K9 usa core_k3k9 e A7 usa core_k3. O binder reconstrói builds e recusa núcleo ambíguo, selo substituído, arquivo adicional/ausente ou hash divergente; nenhum selo é remapeado.

A prova histórica BB teve27casos,23remontagens explícitas e três recusas nos bytes/caminhos da rev3. Ela não prova a cópia atual ou a cópia integral em Linux. A CI matinal nova é gate próprio pendente até seus bytes, head, artefatos, JUnit e selos antes/depois serem reconciliados. Programa alterado exige novo selo, registro deliberado e identidade/revisão antes de novos prepares; não editar fonte/registro/conjunto entre prepare e sign.

### 10.4 Gates dos conjuntos atuais

A lista efetiva é a dispatch_gates da folha BOUND construída para a operação atual, incluindo a revisão CODEX_REVIEW_OF_THE_BOUND_SET quando exigida. Uma tabela estática de regras ou lista vazia no template não dispensa o gate que o binder acrescentou. GATES aponta para o arquivo exato que prova cada requisito desta folha e seus bytes; conferir check --gates antes do passo dependente. Recibo parcial/recusado/incerto mantém HOLD com leitura escrita, efeitos conhecidos e incertezas, até prova e autorização válidas.

O Assino do pedido atual, os pinos/revisão de família e núcleo, continuidade de boot e todos os recibos prévios são próprios. O atoB, os BOUND de segunda, assinatura documental da Emenda2 e um resultado de CI não substituem esses gates. Não fabricar resultado futuro nem repetir dispatch/resume por inferência.

### 10.5 SPARE: HOLD até a autoridade e o estado exatos

Uma recusa SPARE_* exige parar e conservar os conjuntos e recibos. A referência desta tabela explica as regras existentes; não autoriza criar uma reserva nem repetir um programa. Apenas operações cujo contrato e registro da fontec573 permitem spare_of podem ter reserva. BOOTSTRAP_IDENTITY, K3-K9 e A7 não permitem SPARE; o claim permanente do BOOT não é removido ou reparado e uma criação possível consome sua tentativa.

A reserva exige outro pedido vinculado, rótulo distinto, Assino próprio e todos os gates próprios da folha. O principal tem de ser um conjunto assinado verificável da mesma operação, modo, família, fonte e vínculo de host; não pode ser outra reserva. Os efeitos são os mesmos, salvo os campos de slot/janela próprios que a regra K9 compara explicitamente, e a janela da reserva começa depois do fim da janela do principal. O arquivo lateral <principal>.SPARE.json registra exclusivamente a única reserva; não apagar ou reescrever esse registro.

Antes de preparar a reserva e antes do envio, spare_rules/spare_allowed e o gate SPARE_PRIMARY_NEVER_PREPARED conferem de novo o principal, sua raiz e o registro da reserva. O estado EMPTY permite a reserva apenas nas operações que já a admitem. Só CATALOG_INIT, ACTIVATE, K9_PHASE_READ e K9_PHASE_STEP admitem também PREPARED_NEVER_SENT_PAST_ITS_LATEST_START: claim e intent.json do principal, sem spawn.claim, e último início já passado. Essa exceção não vale para outras operações. Estado enviado, recusa no host, incerteza, raiz ausente ou conteúdo inesperado mantém HOLD; uma reserva não é segunda tentativa.

A autoridade exata vem do contrato selado da operação, do pedido/GO/folha próprios e dos gates comprovados. CI, revisão documental, GO antigo, ausência de um recibo ou esta seção não fornecem essa autoridade. Não há receita de execução de SPARE nesta seção; uma recusa deve ser relatada para a decisão correspondente, sem retry inferido.

## 11. Pins atuais e limites da prova

Ver INDEX_BOOTSTRAP_REV7.json para fontec573, registro78eb, helper, wrapper e identidade física medida nesta nova cópia. Os índices/provas rev2/rev3 permanecem históricos e não são a medição ou aceitação desta cópia. O registro tem25entradas/23famílias/cinco núcleos próprios; a cópia manual da seção10.1 exige somente os selos atuais, sem remapear selos históricos. A árvore e a identidade Mac privadas não podem ser transportadas como runtime Linux.

A identidade local exige Python3.12.14 e exchange_calendars4.13.2, stdlib, venv/RECORD e origens físicas por hash; não instala nem faz fallback em operação. Os subprocessos do sistema definidos pelo binder/assemblies têm versão observada separadamente. Não afirmar que todos usam o Python exterior.

As provas anteriores de27casos de cópia/57controles físicos e Linux437binder/151BOOT permanecem históricas. O run37383433689 foi fechado somente no escopo registrado, com11omissões binder e9W1; não é PASS dos novos bytes9fec/7068/987ab. A CI nova exige a suíte integral atual e as provas atuais de cada família; avisos, erros e omissões precisam permanecer explícitos. Os testes dos subprocessos do sistema têm versão observada separada dos intérpretes exteriores.

Omissões históricas não são PASS ou dispensa. Testes locais não provam Linux/host/Docker/systemd, consumo operacional da release/microestrutura, POLICY do host ou gates. A promoção deste runbook, as provas Linux finais e a autorização válida de cada programa permanecem gates próprios.

Esta rev5 mede sua própria identidade física e confere os novos pins, destino protegido e blocos manuais. Os resultados focais atuais são listados no índice próprio; nenhum sealed-copy operativo real, prepare real, sign real, dispatch, Docker, push ou passo de host foi executado na construção/revisão desta cópia. REHEARSAL continua externo ao selo, ligado aos buffers atuais e sem autoridade operacional.


## 12. Cadeia matinal adicional e lacunas documentais

A Emenda2rev4 SHA8ecc6400fcfd2c5254576bbc7c98e52542cc485ab1b75abe6dfe914e74f2dc4e recebeu SIM documental6008049122. Isso não substitui assinatura do dono, PARAMETERS, runtime, revisão/CI dos programas ou gates. A faixa adicional de terça06/10 é08:26–12:30BRT e não substitui a faixa noturna17:38–20:30; BOOT possui apenas o slot09:26–09:31 e tentativa única.

A ordem proposta é E0 → TREE_PRE → BOOT → K3-K9 → A8 → B2 → A7 → TREE_POST → PRIV → DBR → B6-PINS; A5-CALENDAR/A5-IDENT → B5-CHAIN antecedem A8. Cada seta exige o recibo e o estado exatos que a regra enumera; TREE_PRE mantém somente sua exceção PARTIAL estreita antes do BOOT, que não vale como POLICY, e cada rodada de Assino está no INDEX dos PARAMETERS atual. Nenhuma folha fica pronta por constar aqui. A7 confere o mesmo worker/BOOT observado e vem antes de qualquer recreate. As duas TREE matinais consomem a quota; isso não autoriza duas TREE extras à noite. PARTIAL não vale como POLICY.

Os pedidos de capacidade depois de G19 ficam HOLD enquanto o dono não fixar a marca e as janelas exatas, respeitando R1/R2/B4 → LOAD → M4/reload/C4M4r. A faixa E6até20:55 não amplia a capacidade além20:30. LOAD continua noturno; a extensão matinal da PROBE cobre somente CALENDAR e IDENT. K5 não recebeu faixa matinal; as leituras de quarta e X2 de sexta conservam seus gates próprios. G18 é alternativa não selecionada, e nenhuma reserva/data/GO é inferida.

A primeira emissão não recebe definição inventada de collect: cada programa conserva seu contrato e os PARAMETERS nomeiam sua operação real. O INDEX registra separadamente primários, condicionais, alternativasG18 e capacidadeHOLD; Assino prontas atuais permanece0 até recibos, revisões, assinatura documental e gates completos.


## 13. Origem da revisão5 e integridade da cópia

A cópiaMacrev4 integral2bba551c ficou HOLD após aparecerem12nomes extras não listados, apesar dos8825buffers listados manterem hashes exatos. Sua árvore e a instabilidade observada foram preservadas; não houve exclusão ou aceitação dos extras. Esta rev5 é uma nova projeção própria dos buffers explicitamente pinados, em destino novo, com recibo de origem/exclusões e medição física própria. Ela não transforma a origem em árvore íntegra nem reutiliza a identidade física ou os testes da rev4 como prova da nova localização.

A guarda antesprepare fixa os arquivos/source/registro e o caminho do intérprete desta nova cópia. As folhas reais, a revisãoFable, a CIintegral e as autoridades permanecem gates próprios. O ensaio fica externo ao selo. Qualquer nome extra, arquivo ausente, buffer divergente ou identidade incerta recusa a cópia e exige HOLD; não resolver removendo arquivos da origem ou ignorando achados.


## 14. Manifestos atuais e históricos da revisão6

Esta revisão6 é uma nova cópia dos8894buffers regulares explicitamente listados na revisão5, integral7956bd5d23a7d02db5c9a69812be20b4e752565ee8416264d0372bfe493844a3, mais seu manifesto de origem preservado e os três links declarados do interpretador. A origemrev5 permanece intacta. Não transfere sua identidade física nem seus resultados para este novo caminho. A origemrev4 e seus12extras continuam HOLD histórico conforme seção13.

Há dois manifestos atuais com escopos distintos: binder/SHA256SUMS cobre todos os arquivos regulares do contêinerbinder; binder/bind/SHA256SUMS cobre todos os arquivos regulares de bind, a pasta B usada pelas receitas. Cada um exclui apenas ele próprio em seu escopo; o manifesto do contêiner inclui o manifesto de bind. Ambos são reconstruídos e conferidos pelo conjunto exato de arquivos, sem extras. O manifesto externo final cobre o pacote inteiro e inclui ambos. INDEX_BOOTSTRAP_REV7.json nomeia os dois escopos e seus hashes atuais.

O arquivo binder/HISTORICAL_CONTAINER_SHA256SUMS.993135ce preserva os bytes do antigo manifesto do contêiner, que deixou de corresponder aos arquivos atuais após as revisões operativas. Ele é histórico, não manifesto atual nem prova de integridade deste contêiner. REV5_ORIGINAL_SHA256SUMS e historical-runtime-rev5 preservam origem, índice, identidade e wrapper anteriores. Os demais documentos, índices e recibos de revisões anteriores continuam históricos; não são instruções de uso atual.

A medição física e os controles de guarda da revisão6 são feitos neste caminho próprio, sem sealed-copy operativo, prepare, assinatura, host, Docker ou GO. Seus recibos de QA identificam separadamente o Python externo e o runtime efetivo. O selo final depende da revisão dos novos bytes e dos dois manifestos atuais; Linux, revisãoFable, autoridade e conjuntos BOUND permanecem gates independentes.


## 15. Correção dos modos de diretórios antes do selo

A primeira construção desta revisão6 tinha47diretórios compartilhados com a origem em0755, enquanto a origem usa0700. A comparação inicial conferiu buffers e modos dos arquivos regulares, mas não fechou o inventário completo dos diretórios. O candidato e seu manifesto externo proposto a852 ficaram HOLD; esse manifesto nunca foi instalado nem a árvore selada. A causa foi a criação dos ancestrais intermediários com mkdir(parents=True), que não aplica0700 a todos os ancestrais.

Somente os47modos divergentes desta cópia própria foram restaurados conforme a origem, sem alterar arquivos, links, dono, fonte, helper, registro, famílias, núcleos, bytes do venv ou a origemrev5. Todos os diretórios atuais são0700, e todos os compartilhados correspondem aos modos da origem. O recibo DIRECTORY_MODE_REPAIR.public.json lista os47caminhos relativos e suas medidas antes/depois.

A identidade física confere bytes, caminhos e links aprovados, mas não inclui bits de permissão de diretórios. Esses modos são conferidos separadamente contra o inventário de origem e o inventário atual. Como os campos da identidade não mudaram, seu hash e o pin do wrapper continuam iguais. A guarda fria foi repetida após a restauração, e uma segunda rodada atual passou nos dez controles por camada, com Python externo3.9.6/3.12.14 e runtime efetivo3.12.14. A primeira rodada e seus recibos permanecem preservados; não são apresentados como aceite dos modos da árvore inicial.

Os dois manifestos internos atuais foram reconstruídos após a QA e esta nota. O INDEX_BOOTSTRAP_REV7.json aponta os recibos e os manifestos atuais da segunda etapa. O novo manifesto externo permanece somente proposto, à espera da revisão antes do selo. Nenhuma receita, bloco executável ou guarda de autoridade foi ampliada.


## 16. Correção restrita de REQUEST em UTC da revisão7

A fonte anterior9fec e a origem físicaMac6 c66d66b1 permanecem preservadas e HOLD para A7 após o ensaio genuíno em Python3.9 revelar a recusa de horários REQUEST escritos com Z pelo próprio binder. Esta revisão altera somente as duas leituras de not_before/not_after do REQUEST K3 em bootstrap_k3env_identity para parse_utc com o mesmo código BOOTSTRAP_K3_CHAIN_NOT_LINKED. A gramática continua exigindo UTC e segundos inteiros; a interpretação dos relógios de recibos e utc_instant permanece igual. Os bytes dos REQUESTs e recibos do ensaio não foram remapeados.

A Mac7 mede uma identidade física própria e atualiza apenas o pin de fonte no helper e o pin de identidade no wrapper. Registro25,23famílias,5núcleos, destinos, regras de SPARE e os20blocos zsh permanecem iguais à origem. O bloco manual adicional continua guardado e não foi executado. As provas históricas das revisões anteriores não comprovam esta nova localização. As guardas atuais são controles locais de protocolo; nenhuma operação sealed-copy, prepare, assinatura, dispatch, Docker, host ou GO operativo foi executada. A prova portátil539 e a CI Linux são evidências separadas; os12casos omitidos na regressão local permanecem declarados, sem dispensa dos requisitos Linux.

Manifestos atuais: binder/bind/SHA256SUMS cobre o diretório bind inteiro; binder/SHA256SUMS cobre o contêiner binder inteiro; SHA256SUMS na raiz cobre a revisãoMac7. Os manifestos anteriores só estão sob nomes REV6_ORIGINAL_SHA256SUMS e historical-runtime-rev6, e nunca servem como inventário atual. Autoridades, PARAMETERS, conjuntos BOUND, revisãoFable e prova Linux atuais continuam gates próprios.
