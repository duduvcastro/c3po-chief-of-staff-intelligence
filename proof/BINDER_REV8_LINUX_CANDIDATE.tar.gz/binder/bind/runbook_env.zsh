# Sourced at the start of every RUNBOOK block. Fixes the operative interpreter and refuses runtime drift before any block.
# A fresh empty bytecode prefix is created locally; no host, transport or dispatcher is run by sourcing this file.
# Usage, first line of every block:   L=<label>; if source <this file>; then ... fi
setopt noclobber
B="${${(%):-%N}:A:h}"
S="${B:h}"
W="${BIND_WORK_ROOT:?Defina BIND_WORK_ROOT para as cópias locais revisadas}"
PY="${S:h}/venv/bin/python"
BIND="${B}/runtime_checked_binder.py"
PICK="${B}/pick.py"
REPO=duduvcastro/c3po-chief-of-staff-intelligence
ISSUE=429
# The executed bound set the transport fields are copied from (read by the binder, never printed). Durable copy in W.
REFERENCE="${W}/hostfacts01-fable-20261002/bound/DISPATCH.BOUND.json"
W1_FAMILY="${S:h}/legacy/w1"
HOSTOPS_FAMILY="${S:h}/legacy/hostops01"
# HOSTOPS02 candidata: registro25, 23 famílias operativas e cinco núcleos explícitos.
# A cópia candidata usa somente selos atuais; destino novo, conferido pelo wrapper (RUNBOOK10.1).
HOSTOPS02_SOURCE="${S:h}/families"
HOSTOPS02_COPY="${W}/hostops02-sealed-registry25-78eb4ab2"
is_hash() { [[ "$1" =~ '^[0-9a-f]{64}$' ]] }
is_label() { [[ "$1" =~ '^[a-z0-9][a-z0-9-]{0,39}$' ]] }
is_comment_url() { [[ "$1" =~ '^https://github\.com/duduvcastro/c3po-chief-of-staff-intelligence/issues/[0-9]{1,6}#issuecomment-[0-9]{6,20}$' ]] }
is_utc_stamp() { [[ "$1" =~ '^2026-10-(0[2-9]|10)T[0-2][0-9]:[0-5][0-9]:[0-5][0-9]Z$' ]] }
if ! is_label "${L}"; then echo "PARADO: defina L=<label> antes do source (o mesmo label do arquivo de parametros); nada foi feito"; return 1; fi
# Every writable destination is external to the whole sealed operative root.
OPERATIVE_ROOT="${S:h:A}"
is_external_write_path() {
  [[ -n "$1" ]] || return 1
  local actual="${1:A}"
  [[ "${actual}" != "${OPERATIVE_ROOT}" && "${actual}" != "${OPERATIVE_ROOT}/"* ]]
}
external_write_path() {
  is_external_write_path "$1" || { echo 'PARADO: destino de escrita está na cópia selada' >&2; return 1; }
  print -r -- "${1:A}"
}
W=$(external_write_path "${W}") || return 1
RUN_BASE=$(external_write_path "${RUN_BASE:-${W}/binder-runs}") || return 1
RUN=$(external_write_path "${RUN_BASE}/${L}") || return 1
REHEARSAL_BASE=$(external_write_path "${W}/binder-rehearsals") || return 1
# Keep the fixed leaf lexical: resolving a dangling link would hide its existence.
HOSTOPS02_COPY="${W}/hostops02-sealed-registry25-78eb4ab2"
is_external_write_path "${HOSTOPS02_COPY}" || { echo 'PARADO: destino da cópia está na árvore selada'; return 1; }
RUNTIME_TMP_BASE=$(external_write_path "${TMPDIR:-/tmp}") || return 1
BINDER_SELECTED_W="${W}"; BINDER_SELECTED_RUN_BASE="${RUN_BASE}"; BINDER_SELECTED_RUN="${RUN}"
BINDER_SELECTED_REHEARSAL_BASE="${REHEARSAL_BASE}"
BINDER_SELECTED_HOSTOPS02_COPY="${HOSTOPS02_COPY}"
# run.env is written once by block 1a of the runbook: FAMILY, OP, MODE, PARAMS, OUT (a rehearsal also sets REFERENCE and ARCHIVE);
# for HOSTOPS02 also GATES (the dispatch gates file) whenever the sheet lists dispatch gates (blocks 6 and 9 stop without it).
# RESUME_GATE is no longer read: block 9 runs check --step resume for every HOSTOPS02 set.
GATES=""; RESUME_GATE=""
# run.env defines operation inputs only. Re-derive protected code/runtime locations afterwards;
# a PY/BIND/PYFLAGS assignment in that file cannot redirect the interpreter or bypass this guard.
B="${${(%):-%N}:A:h}"
S="${B:h}"
OPERATIVE_ROOT="${S:h}"
PY="${OPERATIVE_ROOT}/venv/bin/python"
BINDER_SOURCE="${B}/bind_once.py"
BIND="${B}/runtime_checked_binder.py"
PICK="${B}/pick.py"
if [[ ! -x "${PY}" || ! -f "${BIND}" ]]; then
  echo 'PARADO: runtime operativo ou verificador ausente; nenhum passo foi executado'
  return 1
fi
RUNTIME_PYC=$(mktemp -d "${RUNTIME_TMP_BASE}/binder-operative-cache.XXXXXXXX") || {
  echo 'PARADO: não foi possível criar prefixo de bytecode vazio; nenhum passo foi executado'
  return 1
}
PYFLAGS=(-I -S -B -X "pycache_prefix=${RUNTIME_PYC}")
# Dispatcher needs its reviewed bound directory for sibling imports; ignore Python environment and user/site hooks.
DISPATCH_PYFLAGS=(-E -s -S -B)
RUNTIME_CHECK_JSON=$("${PY}" "${PYFLAGS[@]}" "${BIND}" --check-runtime)
RUNTIME_CHECK_EXIT=$?
if (( RUNTIME_CHECK_EXIT != 0 )); then
  print -r -- "${RUNTIME_CHECK_JSON}"
  echo 'PARADO: identidade do runtime recusada; não preparar, assinar ou despachar'
  return 1
fi
# Explicit directory creation for block1a/manualrehearsals; sourcing never creates run folders.
create_external_private_directory() {
  local TARGET
  TARGET=$(external_write_path "$1") || return 1
"${PY}" "${PYFLAGS[@]}" - "${TARGET}" "${OPERATIVE_ROOT}" <<'BINDER_EXTERNAL_DIRS'
import os, stat, sys
from pathlib import Path
root = Path(sys.argv[-1]).resolve()
paths = [Path(value) for value in sys.argv[1:-1]]
for path in paths:
    resolved = path.resolve()
    if resolved == root or root in resolved.parents or resolved != path:
        raise SystemExit('PARADO: destino externo inválido ou mudou durante validação')
for path in paths:
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for component in path.parts[1:]:
            created = False
            try:
                next_fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            except FileNotFoundError:
                os.mkdir(component, mode=0o700, dir_fd=fd)
                created = True
                next_fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd); fd = next_fd
            metadata = os.fstat(fd)
            if created and stat.S_IMODE(metadata.st_mode) != 0o700:
                raise SystemExit('PARADO: diretório novo não é privado0700')
        leaf = os.fstat(fd)
        if stat.S_IMODE(leaf.st_mode) != 0o700 or leaf.st_uid != os.geteuid():
            raise SystemExit('PARADO: diretório final não é privado0700 deste usuário')
    finally:
        os.close(fd)
BINDER_EXTERNAL_DIRS
local RESULT=$?
if (( RESULT != 0 )); then echo 'PARADO: não foi possível criar diretórios externos privados'; return 1; fi
return 0
}
# Only the manual sealed-copy recipe calls this. Later blocks may use an existing sealed copy.
require_new_hostops02_copy() {
  local EXPECTED="${W}/hostops02-sealed-registry25-78eb4ab2"
  if [[ "${HOSTOPS02_COPY}" != "${EXPECTED}" || "${HOSTOPS02_COPY}" != "${BINDER_SELECTED_HOSTOPS02_COPY}" ]]; then
    echo 'PARADO: destino da cópia do registro25 foi alterado'; return 1
  fi
  if [[ -e "${EXPECTED}" || -L "${EXPECTED}" ]]; then
    echo 'PARADO: destino da cópia do registro25 já existe; não reutilizar, mover ou apagar'; return 1
  fi
  if [[ "${EXPECTED:A}" != "${EXPECTED}" ]] || ! is_external_write_path "${EXPECTED}"; then
    echo 'PARADO: destino da cópia do registro25 não é o caminho fixo externo'; return 1
  fi
  return 0
}
# Runtime was checked before reading operation inputs. Re-check after loading them.
if [[ -f "${RUN}/run.env" ]]; then source "${RUN}/run.env"; ATTEMPT="${OUT}/.dispatch-root/${L}-once"; fi
# Re-derive the sealed root before testing any writable input.
B="${${(%):-%N}:A:h}"
S="${B:h}"
OPERATIVE_ROOT="${S:h}"
# Operation inputs cannot redirect the selected external workspace or run directory.
if [[ "${W}" != "${BINDER_SELECTED_W}" || "${RUN_BASE}" != "${BINDER_SELECTED_RUN_BASE}" || "${RUN}" != "${BINDER_SELECTED_RUN}" || "${REHEARSAL_BASE}" != "${BINDER_SELECTED_REHEARSAL_BASE}" || "${HOSTOPS02_COPY}" != "${BINDER_SELECTED_HOSTOPS02_COPY}" ]]; then
  echo 'PARADO: run.env tentou alterar destinos de escrita protegidos'; return 1
fi
for WRITE_TARGET in "${W}" "${RUN_BASE}" "${RUN}" "${REHEARSAL_BASE}" "${HOSTOPS02_COPY}" "${OUT:-}" "${ARCHIVE:-}"; do
  [[ -z "${WRITE_TARGET}" ]] && continue
  is_external_write_path "${WRITE_TARGET}" || { echo 'PARADO: parâmetro aponta destino de escrita na cópia selada'; return 1; }
done
# The only answer that is a signature. A rehearsal has no owner and no answer: its marker is what the binder accepts there.
if [[ "${MODE}" == rehearsal ]]; then ANSWER_WORD=REHEARSAL_NO_OWNER_ANSWER; else ANSWER_WORD=Assino; fi
B="${${(%):-%N}:A:h}"
S="${B:h}"
OPERATIVE_ROOT="${S:h}"
PY="${OPERATIVE_ROOT}/venv/bin/python"
BIND="${B}/runtime_checked_binder.py"
PICK="${B}/pick.py"
PYFLAGS=(-I -S -B -X "pycache_prefix=${RUNTIME_PYC}")
# Dispatcher needs its reviewed bound directory for sibling imports; ignore Python environment and user/site hooks.
DISPATCH_PYFLAGS=(-E -s -S -B)
RUNTIME_CHECK_JSON=$("${PY}" "${PYFLAGS[@]}" "${BIND}" --check-runtime)
RUNTIME_CHECK_EXIT=$?
if (( RUNTIME_CHECK_EXIT != 0 )); then
  print -r -- "${RUNTIME_CHECK_JSON}"
  echo 'PARADO: identidade mudou durante leitura dos parâmetros; nenhum passo dependente'
  return 1
fi
return 0
